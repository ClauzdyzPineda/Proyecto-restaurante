/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import ejb.TipoComplementoFacadeLocal;
import entity.TipoComplemento;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

/**
 *
 * @author claudia.pinedausam
 */
@Named(value = "cTipoComplemento")
@SessionScoped
public class CTipoComplemento implements Serializable {

    @EJB
    private TipoComplementoFacadeLocal tipComEJB;
    private TipoComplemento tipoComplemento;
    private List<TipoComplemento> lista;
    private String msj = "";

    public TipoComplemento getTipoComplemento() {
        return tipoComplemento;
    }

    public void setTipoComplemento(TipoComplemento tipoComplemento) {
        this.tipoComplemento = tipoComplemento;
    }

    public List<TipoComplemento> getLista() {
        lista = tipComEJB.findAll();
        return lista;
    }

    public void setLista(List<TipoComplemento> lista) {
        this.lista = lista;
    }

    @PostConstruct
    public void init() {
        this.tipoComplemento = new TipoComplemento();
    }

    public void create() {
        FacesMessage mensa;
        try {
            tipComEJB.create(tipoComplemento);
            msj = "Datos guardados correctamente";
            mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Completado", msj);
            init();
            refresh();
        } catch (Exception e) {
            msj = "Error al guardar" + e.getMessage();
            System.out.println("Error" + e.getMessage());
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", msj);
        }
        FacesContext.getCurrentInstance().addMessage(msj, mensa);
    }

    public void refresh() {
        lista = tipComEJB.findAll();
        init();
    }

    public void delete(TipoComplemento tc) {
        FacesMessage mensa;
        try {
            tipComEJB.delete(tc);
            msj = "Datos eliminados correctamente";
            mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Completado", msj);
            refresh();
        } catch (Exception e) {
            msj = "Error al Eliminar" + e.getMessage();
            System.out.println("Error" + e.getMessage());
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", msj);
        }
        FacesContext.getCurrentInstance().addMessage(msj, mensa);
    }

    public void update() {
        FacesMessage mensa;
        try {
            tipComEJB.edit(tipoComplemento);
            msj = "Datos actualizados";
            mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Completado", msj);
            init();
            refresh();
        } catch (Exception e) {
            msj = "Error al actualizar" + e.getMessage();
            System.out.println("Error" + e.getMessage());
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", msj);
        }
        FacesContext.getCurrentInstance().addMessage(msj, mensa);
    }

    public void find(TipoComplemento tc) {
        FacesMessage mensa;
        try {
            this.tipoComplemento = tc;
            this.msj = "Registro cargado correctamente";
            mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Completado", msj);
        } catch (Exception e) {
            e.printStackTrace();
            this.msj = "No se pudo cargar la información...";
            System.err.println("Error al cargar registro : " + e.getMessage());
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Ups", msj);
        }
        FacesContext.getCurrentInstance().addMessage(msj, mensa);
    }
}
