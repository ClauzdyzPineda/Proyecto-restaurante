/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import entity.Producto;
import entity.ScaPlatillo;
import ejb.ProductoFacadeLocal;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

@Named(value = "cProducto")
@SessionScoped
public class CProducto implements Serializable {

    @EJB
    private ProductoFacadeLocal productoEJB;
    private Producto pro;
    private List<Producto> lista;
    
    //Mensaje informativo
    private String msj;

    /*LISTAS BEBIDAS Y COMPLEMENTOS AUN NO IMPLEMENTADAS*/
    private List<Producto> listabebidas;
    private List<Producto> listaComplemento;

    /*LISTAS DE INGREDIENTES*/
    private List<Producto> listaIng;

    /*LISTA DE INGREDIENTES EXCLUYENDO LAS BEBIDAS*/
    public List<Producto> getListaIng() {
        this.listaIng = this.productoEJB.listaIng();
        return listaIng;
    }

    public void setListaIng(List<Producto> listaIng) {
        this.listaIng = listaIng;
    }

    public Producto getPro() {
        return pro;
    }

    public void setPro(Producto pro) {
        this.pro = pro;
    }

    public List<Producto> getLista() {
        this.lista = this.productoEJB.findAll();
        return lista;
    }

    public void setLista(List<Producto> lista) {
        this.lista = lista;
    }

    public List<Producto> getListabebidas() {
        this.listabebidas = this.productoEJB.getBebidas();
        return listabebidas;
    }

    public void setListabebidas(List<Producto> listabebidas) {
        this.listabebidas = listabebidas;
    }

    public List<Producto> getListaComplemento() {
        this.listabebidas = this.productoEJB.getComplementos();
        return listaComplemento;
    }

    public void setListaComplemento(List<Producto> listaComplemento) {
        this.listaComplemento = listaComplemento;
    }

    @PostConstruct
    public void init() {
        pro = new Producto();
    }

    public void clear() {
        init();
        this.lista = this.productoEJB.findAll();
    }

    public void save() {
        FacesMessage mensa;
        try {
            this.pro.setEstado("Stock");
            productoEJB.create(pro);
            clear();
            msj = "Datos guardados correctamente";
            mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Completado", msj);
            clear();
        } catch (Exception e) {
            msj = "Error al guardar por " + e.getMessage();
            System.out.println("No guarda por " + e.getMessage());
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", msj);
        }
        FacesContext.getCurrentInstance().addMessage(msj, mensa);
    }

    public void delete(Producto id) {
        FacesMessage mensa;
        try {
            this.productoEJB.delete(id);
            msj = "Datos eliminados correctamente";
            clear();
            mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Completado", msj);
        } catch (Exception e) {
            msj = "Error al eliminar por " + e.getMessage();
            System.out.println("No elimina por " + e.getMessage());
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", msj);
        }
        FacesContext.getCurrentInstance().addMessage(msj, mensa);
    }

    public void update() {
        FacesMessage mensa;
        try {
            productoEJB.edit(pro);
            msj = "Datos actualizados correctamente";
            mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Completado", msj);
            clear();
        } catch (Exception e) {
            System.out.println("No actualiza por " + e.getMessage());
            msj = "No se logro eliminar el registro";
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Algo fallò", msj);
        }
        FacesContext.getCurrentInstance().addMessage(msj, mensa);

    }

    public void find(Producto id) {
        try {
            this.pro = id;
        } catch (Exception e) {
            System.out.println("No actualiza por " + e.getMessage());
        }
    }

}
