/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 *
 * @author serafin
 */
public class date {

//    public static void main(String[] args) {
//
//        Date date = new Date();
//        String format = "dd/MM/yyyy";
//        String fullFormat = "dd/MM/yyyy HH:mm";
//        try {
//            //Obtenemos solo el día del registro
//            SimpleDateFormat formateo = new SimpleDateFormat(format);
//            String dia = formateo.format(date);
//
//            //Concatenamos la hora cero al día y la hora 23 al día
//            String fechaInicial = dia + " 00:00:00";
//            String fechaFinal = dia + " 23:59:59";
//            //Creamos un nuevo formato con las horas creadas
//            SimpleDateFormat full = new SimpleDateFormat(fullFormat);
//            //Parseamos para obtener el inicio y final del día basandonos en la fecha de nuestro registro
//            Date d1 = full.parse(fechaInicial);
//            Date d2 = full.parse(fechaFinal);
//            System.out.println(d1 + " " + d2);
//
//        } catch (Exception e) {
//        }
//    }
    public static void main(String[] args) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        SimpleDateFormat sdf2 = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        Calendar cal = Calendar.getInstance();
        Calendar cal2 = Calendar.getInstance();
        try {
            System.out.println("FECHA ACTUAL  " + sdf.format(cal.getTime()));

            int month = cal.get(Calendar.MONTH) + 1;
            int day = cal.get(Calendar.DAY_OF_MONTH);

            int year = cal.get(Calendar.YEAR);
            System.out.println(day + " " + month + " " + year);

            Date date = new Date();
            SimpleDateFormat format = new SimpleDateFormat("M");
            System.out.println(format.format(date));

//A la fecha actual le pongo el día 1 y para el ultimo seteamos su actual maximum
            cal.set(Calendar.DAY_OF_MONTH, 1);
            cal2.set(Calendar.DAY_OF_MONTH, cal2.getActualMaximum(Calendar.DAY_OF_MONTH));
            System.out.println("Primer día del mes actual:" + sdf2.format(cal.getTime()));
            System.out.println("Último día del mes actual:" + sdf2.format(cal2.getTime()));

            String diaI = sdf.format(cal.getTime()) + " " + "00:00:00" ;
            String diaF = sdf.format(cal2.getTime()) + " " + "23:59:59";
            
            
            
            
            Date d1 = sdf2.parse(diaI);
            Date d2 = sdf2.parse(diaF);
            System.out.println(d1 + " " + d2);
            System.out.println(diaI + " " + diaF);
            
            Date dadad = new SimpleDateFormat("dd/MM/yyyy HH:mm").parse("28/04/2020 00:00");
            System.out.println(dadad);
        } catch (Exception e) {
        }

    }

}
