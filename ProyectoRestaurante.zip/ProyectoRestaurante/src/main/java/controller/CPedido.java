/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import entity.Pedido;
import entity.Producto;
import entity.Sucursal;
import entity.Usuario;
import ejb.PedidoFacadeLocal;
import entity.Persona;
import entity.Proveedor;
import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Named;

@Named(value = "cPedido")
@SessionScoped
public class CPedido implements Serializable {

    @EJB
    private PedidoFacadeLocal pedidoEJB;
    private Pedido ped;
    private List<Pedido> lista;

    /*FORANEAS*/
    private Proveedor prov;
    private Producto prod;
    private Usuario usu;
    private Sucursal suc;

    //Mensaje informativo
    private String msj;

    //Atributos especiales para usuario nivel 2
    private List<Pedido> listUser;

    public List<Pedido> getListUser() {
        Usuario us = (Usuario) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("Usuario");

        /*MANDAMOS A RECOJER LA PERSONA CORRESPONDIENTE Y POR NDE SU RESPECTIVA SUCURSAL*/
        Persona per = this.pedidoEJB.getPersona(us);
        /*SETEAMOS LA ID DE LA SUCURSAL A LA ENTIDAD*/
        Sucursal s = new Sucursal();
        s.setId_sucursal(per.getId_sucursal().getId_sucursal());
        this.listUser = this.pedidoEJB.getPedSucursal(s);
        return listUser;
    }

    public void setListUser(List<Pedido> listUser) {
        this.listUser = listUser;
    }

    /*getter ands setter*/
    public Pedido getPed() {
        return ped;
    }

    public void setPed(Pedido ped) {
        this.ped = ped;
    }

    public List<Pedido> getLista() {
        this.lista = this.pedidoEJB.findAll();
        return lista;
    }

    public void setLista(List<Pedido> lista) {
        this.lista = lista;
    }

    public Proveedor getProv() {
        return prov;
    }

    public void setProv(Proveedor prov) {
        this.prov = prov;
    }

    public Producto getProd() {
        return prod;
    }

    public void setProd(Producto prod) {
        this.prod = prod;
    }

    public Usuario getUsu() {
        return usu;
    }

    public void setUsu(Usuario usu) {
        this.usu = usu;
    }

    public Sucursal getSuc() {
        return suc;
    }

    public void setSuc(Sucursal suc) {
        this.suc = suc;
    }

    @PostConstruct
    public void init() {
        ped = new Pedido();
        prov = new Proveedor();
        prod = new Producto();
        usu = new Usuario();
        suc = new Sucursal();
    }

    public void refresh() {
        this.lista = this.pedidoEJB.findAll();
        init();
    }

    public void refreshDetailed() {
        try {
            Usuario us = (Usuario) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("Usuario");

            /*MANDAMOS A RECOJER LA PERSONA CORRESPONDIENTE Y POR NDE SU RESPECTIVA SUCURSAL*/
            Persona per = this.pedidoEJB.getPersona(us);
            /*SETEAMOS LA ID DE LA SUCURSAL A LA ENTIDAD*/
            Sucursal s = new Sucursal();
            s.setId_sucursal(per.getId_sucursal().getId_sucursal());
            this.listUser = this.pedidoEJB.getPedSucursal(s);
            init();
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Error refreshDetailed " + e.getMessage());
        }
    }

    //Método para guardar
    public void save() {
        /*VARIABLE QUE MANDAREMOS PARA EL MÉTODO PERSONALIZADO*/
        Usuario us = null;
        /*PARA RECOJER LO QUE RECIBIMOS DEL MÉTODO*/
        Persona per = null;
        FacesMessage mensa;
        Date d = new Date();
        try {
            /*RECOJEMOS LA SESIÓN*/
            us = (Usuario) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("Usuario");
            /*MANDAMOS A RECOJER LA PERSONA CORRESPONDIENTE Y POR NDE SU RESPECTIVA SUCURSAL*/
            per = this.pedidoEJB.getPersona(us);
            /*SETEAMOS LA ID DE LA SUCURSAL A LA ENTIDAD*/
            this.suc.setId_sucursal(per.getId_sucursal().getId_sucursal());

            /*SETEAMOS LOS VALORES*/
            this.usu = us;

            this.ped.setFecha_hora(d);

            this.ped.setId_proveedor(prov);
            this.ped.setId_producto(prod);

            //Obtenemos el costo unitario
            double costo_uni = pedidoEJB.getValor_Pro(ped.getId_producto().getId_producto());
            double valor = (costo_uni * ped.getCant_producto());
            System.err.println(valor);
            
            //Seteamos el valor estimado
            this.ped.setValor_estimado(valor);
            this.ped.setId_usuario(usu);
            this.ped.setId_sucursal(suc);
            this.pedidoEJB.create(ped);

            switch (us.getId_rolesUsuario().getId_rolesUsuario()) {
                case 2:
                    refreshDetailed();
                    break;
                case 3:
                    break;
                default:
                    refresh();
                    break;
            }           
            init();
            msj = "Datos guardados correctamente";
            mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Completado", msj);
        } catch (Exception e) {
            msj = "Error al guardar " + e.getMessage();
            System.out.println("No guarda por " + e.getMessage());
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", msj);
        }
        FacesContext.getCurrentInstance().addMessage(msj, mensa);
    }

    //Método para eliminar
    public void delete(Pedido id) {
        Usuario us = (Usuario) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("Usuario");
        FacesMessage mensa;
        try {
            this.pedidoEJB.delete(id);

            switch (us.getId_rolesUsuario().getId_rolesUsuario()) {
                case 2:
                    refreshDetailed();
                    break;
                case 3:
                    break;
                default:
                    refresh();
                    break;
            }
            init();
            msj = "Datos eliminados correctamente";
            mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Completado", msj);
        } catch (Exception e) {
            msj = "Error al eliminar por " + e.getMessage();
            System.out.println("No elimina por " + e.getMessage());
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", msj);
        }
        FacesContext.getCurrentInstance().addMessage(msj, mensa);
    }

    //Método para actualizar
    public void update() {
        Usuario us = (Usuario) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("Usuario");
        FacesMessage mensa;
        try {
            /*SETEAMOS LOS VALORES*/
            this.ped.setId_proveedor(prov);
            this.ped.setId_producto(prod);
            
            //Obtenemos el costo unitario
            double costo_uni = pedidoEJB.getValor_Pro(ped.getId_producto().getId_producto());
            double valor = (costo_uni * ped.getCant_producto());
            
            //Seteamos el valor estimado
            this.ped.setValor_estimado(valor);
            
            this.ped.setId_usuario(usu);
            this.ped.setId_sucursal(suc);
            this.pedidoEJB.edit(ped);
            
            switch (us.getId_rolesUsuario().getId_rolesUsuario()) {
                case 2:
                    refreshDetailed();
                    break;
                case 3:
                    break;
                default:
                    refresh();
                    break;
            }
            init();
            msj = "Datos modificados correctamente";
            mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Completado", msj);
        } catch (Exception e) {
            msj = "Error al actualizar " + e.getMessage();
            System.out.println("No modifica por " + e.getMessage());
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", msj);
        }
        FacesContext.getCurrentInstance().addMessage(msj, mensa);
    }

    //Método para cargar
    public void find(Pedido id) {
        try {
            this.suc.setId_sucursal(id.getId_sucursal().getId_sucursal());
            this.prov.setId_proveedor(id.getId_proveedor().getId_proveedor());
            this.prod.setId_producto(id.getId_producto().getId_producto());
            this.usu.setId_usuario(id.getId_usuario().getId_usuario());
            this.ped = id;
        } catch (Exception e) {
            System.out.println("No se logro cargar " + e.getMessage());
        }
    }

}
