/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import ejb.PersonaFacadeLocal;
import entity.Cargo;
import entity.Persona;
import entity.Sucursal;
import entity.Usuario;
import java.io.Serializable;
import java.util.List;
import java.util.Locale;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Named;

@Named(value = "cPersona")
@SessionScoped
public class CPersona implements Serializable {

    @EJB
    private PersonaFacadeLocal perEJB;
    private Persona per;
    private List<Persona> lista;
    private List<Persona> filter;

    //Foraneas
    private Cargo car;
    private Sucursal suc;
    //Mensaje Informativo
    String mensa = "";

    //Atributos para usuario nivel 2
    private List<Persona> listUser;

    public List<Persona> getListUser() {
        Usuario us = (Usuario) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("Usuario");
        /*MANDAMOS A RECOJER LA PERSONA CORRESPONDIENTE Y POR NDE SU RESPECTIVA SUCURSAL*/
        Persona per = this.perEJB.getPersona(us);
        /*SETEAMOS LA ID DE LA SUCURSAL A LA ENTIDAD*/
        Sucursal s = new Sucursal();
        s.setId_sucursal(per.getId_sucursal().getId_sucursal());
        this.listUser = this.perEJB.getPerSucursal(s);
        return listUser;
    }

    public void setListUser(List<Persona> listUser) {
        this.listUser = listUser;
    }

    /*------GET Y SET GENERALES-----*/
    public List<Persona> getLista() {
        lista = perEJB.findAll();
        return lista;
    }

    public List<Persona> getFilter() {
        return filter;
    }

    public void setFilter(List<Persona> filter) {
        this.filter = filter;
    }

    public void setLista(List<Persona> lista) {
        this.lista = lista;
    }

    public Persona getPer() {
        return per;
    }

    public void setPer(Persona per) {
        this.per = per;
    }

    public Cargo getCar() {
        return car;
    }

    public void setCar(Cargo car) {
        this.car = car;
    }

    public Sucursal getSuc() {
        return suc;
    }

    public void setSuc(Sucursal suc) {
        this.suc = suc;
    }

    @PostConstruct
    public void init() {
        per = new Persona();
        car = new Cargo();
        suc = new Sucursal();

    }

    public void refresh() {
        this.lista = this.perEJB.findAll();
        init();
    }

    public void refreshUserList() {
        try {
            Usuario us = (Usuario) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("Usuario");
            /*MANDAMOS A RECOJER LA PERSONA CORRESPONDIENTE Y POR NDE SU RESPECTIVA SUCURSAL*/
            Persona per = this.perEJB.getPersona(us);
            /*SETEAMOS LA ID DE LA SUCURSAL A LA ENTIDAD*/
            Sucursal s = new Sucursal();
            s.setId_sucursal(per.getId_sucursal().getId_sucursal());
            this.listUser = this.perEJB.getPerSucursal(s);
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Error refreshUserList " + e.getMessage());
        }
    }

    public void create() {
        FacesMessage message;
        try {
            per.setId_cargo(car);
            per.setId_sucursal(suc);
            perEJB.create(per);
            init();
            refresh();
            message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Exito", "Datos Guardados");
        } catch (Exception e) {
            message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "Error al guardar");
        }
        FacesContext.getCurrentInstance().addMessage(null, message);
    }

    public void update() {
        FacesMessage message;
        try {
            per.setId_cargo(car);
            per.setId_sucursal(suc);
            perEJB.edit(per);
            init();
            refresh();
            message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Exito", "Datos Modificados");
        } catch (Exception e) {
            message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "Error al Modificar");
        }
        FacesContext.getCurrentInstance().addMessage(null, message);
    }

    public void delete(Persona per) {
        FacesMessage message;
        try {
            perEJB.delete(per);
            init();
            refresh();
            message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Exito", "Datos Eliminados");
        } catch (Exception e) {
            message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "Error al Eliminar");
        }
        FacesContext.getCurrentInstance().addMessage(null, message);
    }

    public void find(Persona id) {
        try {
            this.per.setId_cargo(car);
            this.per.setId_sucursal(suc);
            this.per = id;
            perEJB.find(per.getId_persona());
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("ERROR AL MOSTRAR INFO");
        }
    }

    /*EN PRUEBAS*/
    public boolean globalFilterFunction(Object value, Object filter, Locale locale) {
        String filterText = (filter == null) ? null : filter.toString().trim().toLowerCase();
        if (filterText == null || filterText.equals("")) {
            return true;
        }
        int filterInt = getInteger(filterText);

        Persona pers = (Persona) value;

        return pers.getNombres().toLowerCase().contains(filterText)
                || pers.getApellidos().toLowerCase().contains(filterText)
                || pers.getDui().toLowerCase().contains(filterText)
                || pers.getGenero().toLowerCase().contains(filterText)
                || pers.getNit().toLowerCase().contains(filterText)
                || pers.getId_cargo().getCargo().toLowerCase().contains(filterText)
                || pers.getId_sucursal().getNombre().toLowerCase().contains(filterText)
                || pers.getId_persona() > filterInt;
    }

    private int getInteger(String string) {
        try {
            return Integer.valueOf(string);
        } catch (NumberFormatException ex) {
            return 0;
        }
    }

}
