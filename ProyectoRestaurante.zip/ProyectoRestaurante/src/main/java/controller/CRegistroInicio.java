/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import ejb.RegistroInicioFacadeLocal;
import entity.DetalleProducto;
import entity.DetalleVenta;
import entity.Persona;
import entity.RegistrosInicio;
import entity.Sucursal;
import entity.Usuario;
import entity.Venta;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

/**
 *
 * @author andy.chuyusam
 *
 */
@Named(value = "cRegistroInicio")
@SessionScoped
public class CRegistroInicio implements Serializable {

    @EJB
    private RegistroInicioFacadeLocal regIniEJB;
    private RegistrosInicio reg;
    private List<RegistrosInicio> lista;

    /*MENSAJE*/
    private String msj;

    /*FORANEAS*/
    private Usuario usu;
    private Sucursal suc;

    /*LISTA DE VENTAS Y COMPRAS EN El DIA*/
    private List<Venta> listvnt;
    private List<DetalleVenta> listaDetVnt;
    private List<DetalleProducto> listDetpro;

    /*PARA TOTALES Y BALANCE*/
    private double totalVnt;
    private double totalDetPro;

    public double getTotalVnt() {
        return totalVnt;
    }

    public void setTotalVnt(double totalVnt) {
        this.totalVnt = totalVnt;
    }

    public double getTotalDetPro() {
        return totalDetPro;
    }

    public void setTotalDetPro(double totalDetPro) {
        this.totalDetPro = totalDetPro;
    }

    public RegistrosInicio getReg() {
        return reg;
    }

    public void setReg(RegistrosInicio reg) {
        this.reg = reg;
    }

    public List<RegistrosInicio> getLista() {
        this.lista = regIniEJB.findAll();
        return lista;
    }

    public void setLista(List<RegistrosInicio> lista) {
        this.lista = lista;
    }

    public Usuario getUsu() {
        return usu;
    }

    public void setUsu(Usuario usu) {
        this.usu = usu;
    }

    public Sucursal getSuc() {
        return suc;
    }

    public void setSuc(Sucursal suc) {
        this.suc = suc;
    }

    public List<Venta> getListvnt() {
        return listvnt;
    }

    public void setListvnt(List<Venta> listvnt) {
        this.listvnt = listvnt;
    }

    public List<DetalleProducto> getListDetpro() {
        return listDetpro;
    }

    public void setListDetpro(List<DetalleProducto> listDetpro) {
        this.listDetpro = listDetpro;
    }

    public List<DetalleVenta> getListaDetVnt() {
        return listaDetVnt;
    }

    public void setListaDetVnt(List<DetalleVenta> listaDetVnt) {
        this.listaDetVnt = listaDetVnt;
    }

    @PostConstruct
    public void init() {
        this.reg = new RegistrosInicio();
        this.usu = new Usuario();
        this.suc = new Sucursal();
    }

    public void clear() {
        this.reg = new RegistrosInicio();
        this.listDetpro = null;
        this.listvnt = null;
        this.totalDetPro = 0.00;
        this.totalVnt = 0.00;
    }

    public void refresh() {
        this.lista = regIniEJB.findAll();
    }

    public void save(short type) {
        /*VARIABLE QUE MANDAREMOS PARA EL MÉTODO PERSONALIZADO*/
        Usuario us = new Usuario();
        /*PARA RECOJER LO QUE RECIBIMOS DEL MÉTODO*/
        Persona per = new Persona();
        FacesMessage mensa = null;
        try {
            /*RECOJEMOS LA SESIÓN*/
            us = (Usuario) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("Usuario");
            /*MANDAMOS A RECOJER LA PERSONA CORRESPONDIENTE Y POR NDE SU RESPECTIVA SUCURSAL*/
            per = this.regIniEJB.getPersona(us);
            /*SETEAMOS LA ID DE LA SUCURSAL A LA ENTIDAD*/
            this.suc.setId_sucursal(per.getId_sucursal().getId_sucursal());
            /*SETEAMOS LA SESIÓN AL USUARIO*/
            this.usu = us;
            this.reg.setId_sucursal(suc);
            this.reg.setId_usuario(usu);

            this.reg.setInv_registrado(regIniEJB.getInvReg());
            this.reg.setValor_inv(regIniEJB.getValorInv());
            this.reg.setFecha_registro(currentDate());

            //Añadismo el tipo dependiendo del parametro recibido
            this.reg.setTipo(type);
            //Creamos el registro
            this.regIniEJB.create(reg);
            init();
            refresh();

            if (type == 0) {
                this.msj = "Registro inicial creado con éxito";
                mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Completado", msj);
            } else if (type == 1) {
                this.msj = "Registro de cierre creado con éxito";
                mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Completado", msj);
            }else{
                this.msj = "NO SE HA ENCONTRADO UN VALOR DE REGISTRO";
                mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "ERROR", msj);
            }

            
        } catch (Exception e) {
            e.printStackTrace();
            this.msj = "Ha ocurrido un error mientras se guardaba el registro";
            System.err.println("Error al ingresar registro : " + e.getMessage());
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Ups", msj);
        }
        FacesContext.getCurrentInstance().addMessage(msj, mensa);
    }

    public void update() {
        FacesMessage mensa = null;
        try {
            this.reg.setId_usuario(usu);
            this.reg.setId_sucursal(suc);
            this.regIniEJB.edit(reg);
            init();
            refresh();
            this.msj = "Registro modificado correctamente";
            mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Completado", msj);
        } catch (Exception e) {
            e.printStackTrace();
            this.msj = "Ha ocurrido un error mientras se guardaba el registro";
            System.err.println("Error al ingresar registro : " + e.getMessage());
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Ups", msj);
        }
        FacesContext.getCurrentInstance().addMessage(msj, mensa);
    }

    public void delete(RegistrosInicio id) {
        FacesMessage mensa = null;
        try {
            this.regIniEJB.delete(id);
            init();
            refresh();
            this.msj = "Registro eliminado correctamente";
            mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Completado", msj);
        } catch (Exception e) {
            e.printStackTrace();
            this.msj = "Ha ocurrido un error mientras se eliminaba el registro";
            System.err.println("Error al ingresar registro : " + e.getMessage());
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Ups", msj);
        }
        FacesContext.getCurrentInstance().addMessage(msj, mensa);
    }

    public void find(RegistrosInicio id) {
        FacesMessage mensa = null;
        try {
            this.suc.setId_sucursal(id.getId_sucursal().getId_sucursal());
            this.usu.setId_usuario(id.getId_usuario().getId_usuario());
            this.reg = id;
            this.msj = "Registro cargado correctamente";
            mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Completado", msj);
        } catch (Exception e) {
            e.printStackTrace();
            this.msj = "No se pudo cargar la información...";
            System.err.println("Error al cargar registro : " + e.getMessage());
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Ups", msj);
        }
        FacesContext.getCurrentInstance().addMessage(msj, mensa);
    }

    public void viewBitacora(RegistrosInicio reg) {
        FacesMessage mensa;
        String format = "dd/MM/yyyy";
        String fullFormat = "dd/MM/yyyy HH:mm";
        try {
            //Obtenemos solo el día del registro
            SimpleDateFormat formateo = new SimpleDateFormat(format);
            String dia = formateo.format(reg.getFecha_registro());
            System.out.println(dia);
            //Concatenamos la hora cero al día 
            String fechaInicial = dia + " 00:00:00";
            String fechaFinal = dia + " 23:59:59";
            //Creamos un nuevo formato con las horas creadas
            SimpleDateFormat full = new SimpleDateFormat(fullFormat);
            //Parseamos para obtener el inicio y final del día basandonos en la fecha de nuestro registro
            Date d1 = full.parse(fechaInicial);
            Date d2 = full.parse(fechaFinal);

            this.listvnt = this.regIniEJB.getTodayVnt(d1, d2);
            this.listDetpro = this.regIniEJB.getTodayDet(d1, d2);
            balance(listDetpro, listvnt);

            this.msj = "INFORMACIÖN CARGADA CON ËXITO";
            mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Completado", msj);
        } catch (Exception e) {
            e.printStackTrace();
            this.msj = e.getMessage();
            mensa = new FacesMessage(FacesMessage.SEVERITY_FATAL, "ERROR", msj);
        }
        FacesContext.getCurrentInstance().addMessage(msj, mensa);
    }

    //Obtener fecha actual 
    public Date currentDate() {
        Date d = null;
        try {
            Date date = new Date();
            String format = "dd/MM/yyyy HH:mm";

            SimpleDateFormat sdate = new SimpleDateFormat(format);
            String dat = sdate.format(date);

            d = sdate.parse(dat);
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("ERROR DE FECHA... " + e.getMessage());
        }
        return d;
    }

    public void balance(List<DetalleProducto> lista1, List<Venta> lista2) {
        try {

            if (!lista1.isEmpty()) {
                for (int i = 0; i < lista1.size(); i++) {
                    DetalleProducto get = lista1.get(i);
                    this.totalDetPro += get.getValor_en_inv();
                }
                System.out.println(totalDetPro);
            } else {
                this.totalDetPro = 0.00;
            }
            if (!lista2.isEmpty()) {
                for (int i = 0; i < lista2.size(); i++) {
                    Venta get = lista2.get(i);
                    this.totalVnt += get.getVenta_total();
                }
                System.out.println(totalVnt);
            } else {
                this.totalVnt = 0.00;
            }

        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("ERROR BALANCE " + e.getMessage());
        }
    }

    public void detailList(Venta v) {
        try {
            this.listaDetVnt = this.regIniEJB.getDetail(v);
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("ERROR GET DETAIL " + e.getMessage());
        }
    }

    public void clearList() {
        listaDetVnt = null;
    }
}
