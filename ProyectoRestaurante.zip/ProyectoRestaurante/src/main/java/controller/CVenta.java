/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import ejb.DetalleVentaFacadeLocal;
import ejb.ProductoFacadeLocal;
import ejb.VentaFacadeLocal;
import entity.Bebida;
import entity.Complemento;
import entity.DetallePlatillo;
import entity.DetalleVenta;
import entity.Persona;
import entity.Platillo;
import entity.Producto;
import entity.Sucursal;
import entity.Usuario;
import entity.Venta;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

/**
 *
 * @author Fernando
 */
@Named(value = "cVenta")
@SessionScoped
public class CVenta implements Serializable {

    @EJB(beanName = "sventa")
    private VentaFacadeLocal ventasEJB;
    private List<Venta> lista;
    private Venta ven;
    private double venta_total = 0.00;

    /*FORANEA*/
    private Usuario usu;
    private Sucursal suc;

    //Entidad secundaria para doble ingreso
    @EJB(beanName = "sdetalle")
    private DetalleVentaFacadeLocal detVenEJB;
    private DetalleVenta detVen;
    private Platillo pla;
    private Bebida beb;
    private Complemento com;
    private List<DetalleVenta> listaDet;

    //Facade para poder restar al inventario
    @EJB(beanName = "prodFacade")
    private ProductoFacadeLocal productoEJB;

    private String msj;

    /*LISTAS DE PLATILLOS, BEBIDAS Y COMPLEMENTOS PEDIDOS*/
    private ArrayList<Platillo> listaPlatillo;
    private ArrayList<Bebida> listaBebidas;
    private ArrayList<Complemento> listaComplemento;

    //Entidad para actualizar inventario
    private Producto pr = new Producto();
    //Entidad para recojer valores de la lista
    private DetallePlatillo d = new DetallePlatillo();

    //Fechas para generar reporte
    private Date date1;
    private Date date2;
    private List<Venta> report;

    //Atributos especiales para Usuario de nivel 2
    private List<Venta> listUser;

    public List<Venta> getListUser() {
        Usuario us = (Usuario) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("Usuario");

        /*MANDAMOS A RECOJER LA PERSONA CORRESPONDIENTE Y POR NDE SU RESPECTIVA SUCURSAL*/
        Persona per = this.ventasEJB.getPersona(us);
        /*SETEAMOS LA ID DE LA SUCURSAL A LA ENTIDAD*/
        Sucursal s = new Sucursal();
        s.setId_sucursal(per.getId_sucursal().getId_sucursal());
        this.listUser = this.ventasEJB.getVntSucursal(s);
        return listUser;
    }

    public void setListUser(List<Venta> listUser) {
        this.listUser = listUser;
    }

    //Atributo especial para Usuario lvl 3
    private List<Venta> listUserVnt;
    private List<Venta> todayvnt;

    public List<Venta> getTodayvnt() {
        Usuario us = (Usuario) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("Usuario");
        todayvnt = ventasEJB.getMyVntDay(us);
        return todayvnt;
    }

    public void setTodayvnt(List<Venta> todayvnt) {
        this.todayvnt = todayvnt;
    }

    public List<Venta> getListUserVnt() {
        Usuario us = (Usuario) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("Usuario");
        listUserVnt = ventasEJB.getVntUserInLog(us);
        return listUserVnt;
    }

    public void setListUserVnt(List<Venta> listUserVnt) {
        this.listUserVnt = listUserVnt;
    }


    /*/--------------------------GETTERS Y SETTERS GENERALES---------------------/*/
    public Date getDate1() {
        date1 = new Date();
        return date1;
    }

    public void setDate1(Date date1) {
        this.date1 = date1;
    }

    public Date getDate2() {
        date2 = new Date();
        return date2;
    }

    public void setDate2(Date date2) {
        this.date2 = date2;
    }

    public List<Venta> getReport() {
        return report;
    }

    public void setReport(List<Venta> report) {
        this.report = report;
    }

    //Listado de registros
    public List<Venta> getLista() {
        this.lista = this.ventasEJB.findAll();
        return lista;
    }

    public void setLista(List<Venta> lista) {
        this.lista = lista;
    }

    public Venta getVen() {
        return ven;
    }

    public void setVen(Venta ven) {
        this.ven = ven;
    }

    public Usuario getUsu() {
        return usu;
    }

    public void setUsu(Usuario usu) {
        this.usu = usu;
    }

    public Platillo getPla() {
        return pla;
    }

    public void setPla(Platillo pla) {
        this.pla = pla;
    }

    public Bebida getBeb() {
        return beb;
    }

    public void setBeb(Bebida beb) {
        this.beb = beb;
    }

    public Complemento getCom() {
        return com;
    }

    public void setCom(Complemento com) {
        this.com = com;
    }

    public DetalleVenta getDetVen() {
        return detVen;
    }

    public void setDetVen(DetalleVenta detVen) {
        this.detVen = detVen;
    }


    /*ARRAYLIST E ID DEL PLATILLO A ELIMINAR, ETC*/
    public ArrayList<Platillo> getListaPlatillo() {
        return listaPlatillo;
    }

    public void setListaPlatillo(ArrayList<Platillo> listaPlatillo) {
        this.listaPlatillo = listaPlatillo;
    }

    public ArrayList<Bebida> getListaBebidas() {
        return listaBebidas;
    }

    public void setListaBebidas(ArrayList<Bebida> listaBebidas) {
        this.listaBebidas = listaBebidas;
    }

    public ArrayList<Complemento> getListaComplemento() {
        return listaComplemento;
    }

    public void setListaComplemento(ArrayList<Complemento> listaComplemento) {
        this.listaComplemento = listaComplemento;
    }

    public Sucursal getSuc() {
        return suc;
    }

    public void setSuc(Sucursal suc) {
        this.suc = suc;
    }

    public double getVenta_total() {
        return venta_total;
    }

    public void setVenta_total(double venta_total) {
        this.venta_total = venta_total;
    }

    public List<DetalleVenta> getListaDet() {
        return listaDet;
    }

    public void setListaDet(List<DetalleVenta> listaDet) {
        this.listaDet = listaDet;
    }

    public Producto getPr() {
        return pr;
    }

    public void setPr(Producto pr) {
        this.pr = pr;
    }

    public DetallePlatillo getD() {
        return d;
    }

    public void setD(DetallePlatillo d) {
        this.d = d;
    }

    /*/--------------------------CIERRE GETTERS Y SETTERS---------------------/*/
    @PostConstruct
    public void init() {
        this.ven = new Venta();
        this.usu = new Usuario();
        this.pla = new Platillo();
        this.beb = new Bebida();
        this.com = new Complemento();
        this.suc = new Sucursal();
        this.listaPlatillo = new ArrayList<>();
        this.listaBebidas = new ArrayList<>();
        this.listaComplemento = new ArrayList<>();
        this.detVen = new DetalleVenta();
        this.venta_total = 0.00;
        this.pr = new Producto();
        this.d = new DetallePlatillo();
    }


    /*HISTORICO DE VENTAS SUPER USUARIO*/
    public void findAll() {
        this.lista = this.ventasEJB.findAll();
        init();
    }

    //REFRESSCAR LAS VENTAS DEL DIA PARA EL USUARIO EN SESIÓN
    public void refreshDayVntList() {
        try {
            init();
            Usuario us = (Usuario) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("Usuario");
            todayvnt = ventasEJB.getMyVntDay(us);
            System.out.println("Lista completaa");
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error al refrescar " + e.getMessage());
        }
    }

    //Listado de ventas para sucursal especifica
    public void refreshDetailed() {
        try {
            Usuario us = (Usuario) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("Usuario");

            /*MANDAMOS A RECOJER LA PERSONA CORRESPONDIENTE Y POR NDE SU RESPECTIVA SUCURSAL*/
            Persona per = this.ventasEJB.getPersona(us);
            /*SETEAMOS LA ID DE LA SUCURSAL A LA ENTIDAD*/
            Sucursal s = new Sucursal();
            s.setId_sucursal(per.getId_sucursal().getId_sucursal());
            this.listUser = this.ventasEJB.getVntSucursal(s);
            init();
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error al refrescar " + e.getMessage());
        }
    }

    //Recargamos las ventas del usuario en sesión
    public void refreshVntUser() {
        try {
            Usuario us = (Usuario) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("Usuario");
            listUserVnt = ventasEJB.getVntUserInLog(us);
            init();
            System.out.println("Lista completaa 2");
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error al refrescar " + e.getMessage());
        }
    }

    //MÉTODO GUARDAR EL CUAL NOS GUARDA LA VENTA Y TODOS SUS RESPECTIVOS SIGUIENTES REGISTROS
    public void save() {
        /*VARIABLE QUE MANDAREMOS PARA EL MÉTODO PERSONALIZADO*/
        Usuario us = null;
        /*PARA RECOJER LO QUE RECIBIMOS DEL MÉTODO*/
        Persona per = new Persona();
        FacesMessage mensa;
        Date d = new Date();
        try {
            /*RECOJEMOS LA SESIÓN*/
            us = (Usuario) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("Usuario");
            /*MANDAMOS A RECOJER LA PERSONA CORRESPONDIENTE Y POR NDE SU RESPECTIVA SUCURSAL*/
            per = this.ventasEJB.getPersona(us);
            /*SETEAMOS LA ID DE LA SUCURSAL A LA ENTIDAD*/
            this.suc.setId_sucursal(per.getId_sucursal().getId_sucursal());
            /*SETEAMOS LOS VALORES*/
            this.usu = us;
            this.ven.setId_sucursal(suc);
            this.ven.setId_usuario(usu);

            if (venta_total > 0.00 && !"".equals(ven.getNombre_cliente())) {
                if (ven.getDui_carnet().equalsIgnoreCase("")) {
                    ven.setDui_carnet("No Otorgado");
                }
                if (ven.getTel().equalsIgnoreCase("")) {
                    ven.setTel("No Otorgado");
                }
                this.ven.setFecha_hora(d);
                this.ven.setVenta_total(venta_total);
                this.ventasEJB.create(ven);

                //Ahora procedemos a guardar el resto de registros
                saveDetail(ven);

                //Recargamos las ventas
                if (us.getId_rolesUsuario().getId_rolesUsuario() == 2) {
                    refreshDetailed();
                } else if (us.getId_rolesUsuario().getId_rolesUsuario() == 3) {
                    refreshDayVntList();
                } else {
                    findAll();
                }
                init();
                this.msj = "Registro guardado con éxito";
                mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Informe", msj);
            } else {
                //SI EL CLIENTE O EL MONTO ES = 0.00
                this.msj = "Hacen falta valores para completar el ingreso";
                mensa = new FacesMessage(FacesMessage.SEVERITY_WARN, "ADVERTENCIA", msj);
            }
        } catch (Exception e) {
            e.printStackTrace();
            this.msj = "Algo ha fallado...";
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Informe", msj + " " + e.getMessage());
        }

        FacesContext.getCurrentInstance().addMessage(msj, mensa);
    }

    //METODO PARA GUARDAR EN LA TABLA DETALLE DE VENTA
    public void saveDetail(Venta venta) {
        try {
            //OBTENEMOS EL TAMAÑO DE LAS LISTAS Y SELECCIONAMOS EL MAYOR
            int A = listaPlatillo.size();
            int B = listaBebidas.size();
            int C = listaComplemento.size();
            int max = 0;
            if (A >= B) {
                if (A >= C) {
                    max = A;
                } else {
                    max = C;
                }
            } else if (B >= C) {
                max = B;
            } else {
                max = C;
            }

            //CREAMOS TRES VARIABLES PARA LOS CONTADORES Y EL ACUMULADOR DEL PRECIO
            int n1 = 0;
            int n2 = 0;
            int n3 = 0;
            double orden = 0.00;

            //REPETIDOR QUE DA UN VALOR A LAS ENTIDADES Y EVALUA SI VIENE O NO VACIA LA LISTA
            for (int i = 0; i < max; i++) {
                if (!listaPlatillo.isEmpty()) {//SI NO ESTA VACIA QUE EJECUTE
                    if (listaPlatillo.size() != n1) {//SI EL CONTADOR ES MENOR AL TAMAÑO DE LA LISTA
                        //lE DAMOS UN VALOR CORRESPONDIENTE A N REGISTRO DE LA LISTA
                        pla = listaPlatillo.get(i);
                        //OBTENEMOS EL PRECIO Y LO ACUMULAMOS
                        orden += pla.getPrecioPlatillo();
                        n1++;
                    } else {
                        pla.setId_platillo(1);
                        orden += 0.00;
                    }
                } else {
                    pla.setId_platillo(1);
                    orden += 0.00;
                }

                if (!listaBebidas.isEmpty()) {
                    if (listaBebidas.size() != n2) {
                        beb = listaBebidas.get(i);
                        orden += beb.getPrecio_bebida();
                        n2++;
                    } else {
                        beb.setId_bebida(1);
                        orden += 0.00;
                    }
                } else {
                    beb.setId_bebida(1);
                    orden += 0.00;
                }

                if (!listaComplemento.isEmpty()) {
                    if (listaComplemento.size() != n3) {
                        com = listaComplemento.get(i);
                        orden += com.getPrecio_complemento();
                        n3++;
                    } else {
                        com.setId_complemento(1);
                        orden += 0.00;
                    }
                } else {
                    com.setId_complemento(1);
                    orden += 0.00;
                }

                //SETEAMOS LAS FORANEAS CORRESPONDIENTES
                this.detVen.setId_bebida(this.beb);
                this.detVen.setId_complemento(this.com);
                this.detVen.setId_platillo(pla);

                this.detVen.setId_venta(venta);
                //AÑADIMOS EL PRECIO DE LA ORDEN
                this.detVen.setPrecio_orden(orden);
                //CREAMOS LA ORDEN PARA X VENTA Y LIMPIAMOS
                this.detVenEJB.create(detVen);
                //Llamamos método para restar valores al inventario
                modifInventory(pla);
                cleanDetail();
                orden = 0.00;
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("ERROR " + e.getMessage());
        }

    }

    //Funcional!!!!!
    //METODO PARA RESTAR INGREDIENTES DEL PLATILLO AL INVENTARIO
    public void modifInventory(Platillo pla) {
        try {
            //Almacenar cantidad y su existencia en inventario
            int cantidad = 0;
            int existencia = 0;

            //Creamos una lista para recojer los ingredientes
            //Ejecutamos el query que nos recoje los ingredientes
            List<DetallePlatillo> list = this.detVenEJB.getDetailList(pla);

            //Repetidor que nos recoje cada uno de los registros contenedores de la cantidad de ingrediente usado
            for (int i = 0; i < list.size(); i++) {
                //Obtenemos el registro
                d = list.get(i);
                //Almacenamos la cantidad
                cantidad = d.getCantidad_producto();
                //Obtenemos el producto
                pr = this.detVenEJB.getProducto(d);
                //Almacenamos la existencia
                existencia = pr.getExistencias();
                //Seteamos la existencia restante a la entidad
                pr.setExistencias(existencia - cantidad);
                //Hacemos un update a la tabla de productos
                productoEJB.edit(pr);

                //Reiniciamos valores
                this.pr = new Producto();
                this.d = new DetallePlatillo();
                cantidad = 0;
                existencia = 0;
            }
            list = null;
            this.pr = new Producto();
            this.d = new DetallePlatillo();
            cantidad = 0;
            existencia = 0;
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("ERROR " + e.getMessage());
        }
    }

    //INICIAMOS LAS ENTIDADES DE LA TABLA DETALLE 
    public void cleanDetail() {
        this.pla = new Platillo();
        this.beb = new Bebida();
        this.com = new Complemento();
        this.detVen = new DetalleVenta();
    }

    //METODO QUE SIRVE PARA CALCULAR EN TIEMPO REAL EL MONTO A VENDER DEPENDIENDO DE LO SELECCIONADO
    public void generate() {
        FacesMessage mensa;
        double monto = 0.00;
        try {
            mensa = null;

            //Condicional si lista esta o no vacia
            if (!listaPlatillo.isEmpty()) {
                //Repetimos para obtener todos los elementos de la lita
                for (int i = 0; i < listaPlatillo.size(); i++) {
                    //Obtenemos un único elemento de la lita
                    this.pla = listaPlatillo.get(i);
                    //Acumulamos el precio en una variable
                    monto += this.pla.getPrecioPlatillo();
                }
                pla = new Platillo();
            }

            if (!listaBebidas.isEmpty()) {
                for (int i = 0; i < listaBebidas.size(); i++) {
                    this.beb = listaBebidas.get(i);
                    monto += this.beb.getPrecio_bebida();
                }
                beb = new Bebida();
            }

            if (!listaComplemento.isEmpty()) {
                for (int i = 0; i < listaComplemento.size(); i++) {
                    this.com = listaComplemento.get(i);
                    monto += this.com.getPrecio_complemento();
                }
                com = new Complemento();
            }
            this.pla = new Platillo();
            this.beb = new Bebida();
            this.com = new Complemento();

            //Si el monto es mayor a cero se actualizar y caso contrario se envia una alerta
            //notificando que se añadio un registro de cero.
            if (monto > 0.00) {
                //Asignamos el valor de la variable a nuestra entidad
                this.venta_total = monto;
                this.msj = "Monto actualizado";
                mensa = new FacesMessage(FacesMessage.SEVERITY_WARN, "Informe", msj);
            } else {
                this.venta_total = monto;
                this.msj = "Espacio vacio añadido";
                mensa = new FacesMessage(FacesMessage.SEVERITY_WARN, "ADVERTENCIA", msj);
            }

        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("ERROR GRAVE " + e.getMessage() + e.getCause());
            this.msj = "Algo ha fallado...";
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Informe", msj + " " + e.getMessage());
        }
        //Creamos el mensaje.
        FacesContext.getCurrentInstance().addMessage(msj, mensa);

    }

    /*----------------------------ZONA DE SELCCIÓN-----------------------------*/
 /*AÑADIR  PLATILLOS*/
    public void añadirPlatillo(Platillo platillo) {
        FacesMessage mensa;
        try {
            //Corroboramos si la entidad viene con valor null
            if (platillo != null) {
                //Añadimos la entidad al ArrayList<>
                listaPlatillo.add(platillo);
                //Creamos un mensaje de confirmación
                this.msj = "Añadido :D";
                mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Informe", msj);
            } else {
                //Si la entidad viene nula
                this.msj = "Ha ocurrido un error inesperado";
                mensa = new FacesMessage(FacesMessage.SEVERITY_WARN, "Informe", msj);
            }
            generate();
        } catch (Exception e) {
            //Encapsulamiento de errores
            e.printStackTrace();
            this.msj = "Algo ha fallado...";
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Informe", msj + " " + e.getMessage());
        }
        //Creamos el mensaje.
        FacesContext.getCurrentInstance().addMessage(msj, mensa);
    }

    /*ELIMINAR PLATILLO*/
    public void clearList(int id) {
        //Al ejecutar recibimos un número 
        //Si es 1 lol igualamos a cero
        if (id == 1) {
            id = 0;
            //Eliminamos ese valor del ArrayList
            this.listaPlatillo.remove(id);

        } else {//Si es uno mayor, lo redubimos en 1, ya que el Array inicia con 0
            id = (id - 1);
            //Removemos
            this.listaPlatillo.remove(id);
        }
        generate();
    }

    /*SELECCION DE BEBIDAS**/
    public void añadirBebida(Bebida bebidas) {
        FacesMessage mensa;
        try {
            if (bebidas != null) {
                listaBebidas.add(bebidas);
                this.msj = "Añadido :D";
                mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Informe", msj);
            } else {
                this.msj = "Ha ocurrido un error inesperado";
                mensa = new FacesMessage(FacesMessage.SEVERITY_WARN, "Informe", msj);
            }
            generate();
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("ERROR GRAVE : " + e.getMessage() + e.getCause());
            this.msj = "Algo ha fallado...";
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Informe", msj + " " + e.getMessage());
        }
        FacesContext.getCurrentInstance().addMessage(msj, mensa);
    }

    /*ELIMINAR BEBIDA*/
    public void clearListBeb(int id) {
        if (id == 1) {
            id = 0;
            this.listaBebidas.remove(id);
        } else {
            id = (id - 1);
            this.listaBebidas.remove(id);
        }
        generate();
    }

    /*SELECCIONAR UN COMPLEMENTO*/
    public void añadirComplemento(Complemento complementos) {
        FacesMessage mensa;
        try {
            if (complementos != null) {
                listaComplemento.add(complementos);
                this.msj = "Añadido :D";
                mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Informe", msj);
            } else {
                this.msj = "Ha ocurrido un error inesperado";
                mensa = new FacesMessage(FacesMessage.SEVERITY_WARN, "Informe", msj);
            }
            generate();
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("ERROR GRAVE : " + e.getMessage() + e.getCause());
            this.msj = "Algo ha fallado...";
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Informe", msj + " " + e.getMessage());
        }
        FacesContext.getCurrentInstance().addMessage(msj, mensa);
    }

    /*ELIMINAR COMPLEMENTO*/
    public void clearListComp(int id) {
        if (id == 1) {
            id = 0;
            this.listaComplemento.remove(id);
        } else {
            id = (id - 1);
            this.listaComplemento.remove(id);
        }
        generate();
    }

    /*----------------------------CIERRE ZONA DE SELECCIÓN-----------------------------*/
    //METODO PARA ACTUALIZAR LOS DATOS DE UNA VENTA
    public void update() {
        /*RECOJEMOS LA SESIÓN*/
        Usuario us = (Usuario) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("Usuario");
        FacesMessage mensa;
        try {
            this.ven.setId_usuario(usu);//Foranea

            if (!ven.getNombre_cliente().equals("")) {
                this.ventasEJB.edit(ven);
                //Recargamos las ventas
                if (us.getId_rolesUsuario().getId_rolesUsuario() == 2) {
                    refreshDetailed();
                } else if (us.getId_rolesUsuario().getId_rolesUsuario() == 3) {
                    refreshDayVntList();
                } else {
                    findAll();
                }
                init();
                this.msj = "Registro modificado con éxito";
                mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Informe", msj);
            } else {
                //Recargamos las ventas
                findAll();
                this.msj = "El nombre no puede ser nulo";
                mensa = new FacesMessage(FacesMessage.SEVERITY_WARN, "AVISO", msj);
            }

        } catch (Exception e) {
            e.printStackTrace();
            this.msj = "Algo ha fallado...";
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Informe", msj + " " + e.getMessage());
        }
        FacesContext.getCurrentInstance().addMessage(msj, mensa);
    }

    //MÉTODO PARA CARGAR LOS DATOS DE UN REGISTRO
    public void find(Venta vn) {
        FacesMessage mensa = null;
        try {
            //SETEAMOS LAS FORANEAS
            this.suc.setId_sucursal(vn.getId_sucursal().getId_sucursal());
            this.usu.setId_usuario(vn.getId_usuario().getId_usuario());
            //IGUALAMOS ENTIDADES PARA RECOJERLAS EN NUESTRA VISTA
            this.ven = vn;
            this.venta_total = vn.getVenta_total();

            //RECOJEMOS EL DETALLE
            this.listaDet = this.ventasEJB.getDetail(ven);
            this.msj = "Datos cargados con éxito";
            mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Informe", msj);
        } catch (Exception e) {
            e.printStackTrace();
            this.msj = "Algo ha fallado...";
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Aviso", msj + " " + e.getMessage());
        }
        FacesContext.getCurrentInstance().addMessage(msj, mensa);
    }

    //MÉTODO PARA BORRAR UNA VENTA REGISTRADA
    public void delete(Venta vn) {
        /*RECOJEMOS LA SESIÓN*/
        Usuario us = (Usuario) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("Usuario");
        FacesMessage mensa;
        try {
            this.ventasEJB.delete(vn);
            this.msj = "Registro eliminado con éxito";
            mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Informe", msj);
            //Recargamos las ventas dependiendo su usuario
            if (us.getId_rolesUsuario().getId_rolesUsuario() == 2) {
                refreshDetailed();
            } else if (us.getId_rolesUsuario().getId_rolesUsuario() == 3) {
                refreshDayVntList();
            } else {
                findAll();
            }
            init();
        } catch (Exception e) {
            e.printStackTrace();
            this.msj = "Algo ha fallado...";
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Informe", msj + " " + e.getMessage());
        }
        FacesContext.getCurrentInstance().addMessage(msj, mensa);
    }

    //BORRAR UNA ORDEN PERTENECIENTE A UNA VENTA
    public void deleteDetail(DetalleVenta id) {
        FacesMessage mensa;
        try {
            //Recojemos el id de la venta
            int det = id.getId_venta().getId_venta();

            //Restamos la orden a la venta total
            this.venta_total -= id.getPrecio_orden();
            //Borramos el registro
            this.detVenEJB.delete(id);

            //Actualizamos el valor de la venta
            this.ven.setVenta_total(venta_total);
            this.ventasEJB.edit(ven);

            //Recargamos la lista
            this.ven.setId_venta(det);
            this.listaDet = this.ventasEJB.getDetail(ven);

            msj = "Orden eliminada correctamente";
            mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "INFORME", msj);
        } catch (Exception e) {
            e.printStackTrace();
            this.msj = "Algo ha fallado...";
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "AVISO", msj + " " + e.getMessage());
        }
        FacesContext.getCurrentInstance().addMessage(msj, mensa);
    }

    //Añadir una nueva orden al platillo
    public void saveDetailVnt() {
        Platillo p = new Platillo();
        Bebida b = new Bebida();
        Complemento c = new Complemento();
        FacesMessage mensa;
        try {
            //Seteamos las entidades correspondientes
            this.detVen.setId_bebida(this.beb);
            this.detVen.setId_complemento(this.com);
            this.detVen.setId_platillo(this.pla);
            this.detVen.setId_venta(ven);

            //Buscamos los registros correspondientes
            p = detVenEJB.getPlatillo(pla);
            b = detVenEJB.getBebida(beb);
            c = detVenEJB.getComplemento(com);

            //Acumulamos el precio de la orden
            double precio = (b.getPrecio_bebida() + c.getPrecio_complemento() + p.getPrecioPlatillo());
            this.detVen.setPrecio_orden(precio);
            //Creamos la orden
            this.detVenEJB.create(detVen);

            //METODO PARA RESTAR AL INVENTARIO
            modifInventory(pla);
            //Acumulamos el valor para actualizar la venta
            this.venta_total += precio;
            this.ven.setVenta_total(venta_total);
            this.ventasEJB.edit(ven);

            this.listaDet = this.ventasEJB.getDetail(ven);
            cleanDetail();
            msj = "Orden añadida correctamente";
            mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "INFORME", msj);
        } catch (Exception e) {
            e.printStackTrace();
            this.msj = "Algo ha fallado...";
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "AVISO", msj + " " + e.getMessage());
        }
        FacesContext.getCurrentInstance().addMessage(msj, mensa);
    }

    //Obtener fecha actual (NO USADO)
    public String currentDate() {
        Date date = new Date();
        String format = "dd/MM/yyyy";
        SimpleDateFormat sdate = new SimpleDateFormat(format);
        String dat = sdate.format(date);
        System.out.println(sdate.format(date));
        return dat;
    }

    //Método para llamar al facde y generar un reporte de registros basado en un intervalo de fechas
    public void reports() {
        try {
            this.report = this.ventasEJB.getReport(this.date1, this.date2);
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("ERROR AL GENERAR!!!" + e.getMessage());
        }
    }

    public void cleanReport() {
        date1 = new Date();
        date2 = new Date();
        report = null;
    }

    public void reportUser() {
        Usuario us = (Usuario) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("Usuario");

        /*MANDAMOS A RECOJER LA PERSONA CORRESPONDIENTE Y POR ENDE SU RESPECTIVA SUCURSAL*/
        Persona per = this.ventasEJB.getPersona(us);
        /*SETEAMOS LA ID DE LA SUCURSAL A LA ENTIDAD*/
        Sucursal s = new Sucursal();
        s.setId_sucursal(per.getId_sucursal().getId_sucursal());
        try {
            this.report = this.ventasEJB.getReportUser(date1, date2, s);
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("ERROR AL GENERAR!!!" + e.getMessage());
        }
    }
}
