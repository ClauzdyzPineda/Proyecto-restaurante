/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import ejb.DetalleProductoFacadeLocal;
import entity.DetalleProducto;
import entity.Persona;
import entity.Producto;
import entity.Proveedor;
import entity.Sucursal;
import entity.Usuario;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

/**
 *
 * @author fernando.barrazausam
 */
@Named(value = "cDetalleProducto")
@SessionScoped
public class CDetalleProducto implements Serializable {

    /*ESTE CONTROLADORE REFERENCIA A LOS PRODUCTOS QUE SE RECIBEN, LA ENTRADA DEL PRODUCTO*/
    @EJB
    private DetalleProductoFacadeLocal detProdEJB;
    private DetalleProducto detProd;
    private List<DetalleProducto> lista;
    //Foráneas
    private Proveedor pro;
    private Producto prod;
    private Usuario usu;
    private Sucursal suc;

    /*MENSAJE DE INFORME*/
    private String msj;

    //ATRIBUTO ESPECIALES USUARIO NIVEL 2
    private List<DetalleProducto> listUser;

    public List<DetalleProducto> getListUser() {
        Usuario us = (Usuario) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("Usuario");
        /*MANDAMOS A RECOJER LA PERSONA CORRESPONDIENTE Y POR NDE SU RESPECTIVA SUCURSAL*/
        Persona per = this.detProdEJB.getPersona(us);
        /*SETEAMOS LA ID DE LA SUCURSAL A LA ENTIDAD*/
        Sucursal s = new Sucursal();
        s.setId_sucursal(per.getId_sucursal().getId_sucursal());
        this.listUser = this.detProdEJB.getDetProSucursal(s);
        return listUser;
    }

    public void setListUser(List<DetalleProducto> listUser) {
        this.listUser = listUser;
    }

    //Getter and setter
    public DetalleProducto getDetProd() {
        return detProd;
    }

    public void setDetProd(DetalleProducto detProd) {
        this.detProd = detProd;
    }

    public List<DetalleProducto> getLista() {
        this.lista = this.detProdEJB.findAll();
        return lista;
    }

    public void setLista(List<DetalleProducto> lista) {
        this.lista = lista;
    }

    public Proveedor getPro() {
        return pro;
    }

    public void setPro(Proveedor pro) {
        this.pro = pro;
    }

    public Producto getProd() {
        return prod;
    }

    public void setProd(Producto prod) {
        this.prod = prod;
    }

    public Usuario getUsu() {
        return usu;
    }

    public void setUsu(Usuario usu) {
        this.usu = usu;
    }

    public Sucursal getSuc() {
        return suc;
    }

    public void setSuc(Sucursal suc) {
        this.suc = suc;
    }

    @PostConstruct
    public void init() {
        detProd = new DetalleProducto();
        pro = new Proveedor();
        prod = new Producto();
        usu = new Usuario();
        suc = new Sucursal();
    }

    //Mismo método para limpiar
    public void clear() {
        detProd = new DetalleProducto();
        pro = new Proveedor();
        prod = new Producto();
        usu = new Usuario();
        suc = new Sucursal();
    }

    public void refresh() {
        this.lista = this.detProdEJB.findAll();
        clear();
    }

    public void refreshDetail() {
        try {
            Usuario us = (Usuario) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("Usuario");
            /*MANDAMOS A RECOJER LA PERSONA CORRESPONDIENTE Y POR NDE SU RESPECTIVA SUCURSAL*/
            Persona per = this.detProdEJB.getPersona(us);
            /*SETEAMOS LA ID DE LA SUCURSAL A LA ENTIDAD*/
            Sucursal s = new Sucursal();
            s.setId_sucursal(per.getId_sucursal().getId_sucursal());
            this.listUser = this.detProdEJB.getDetProSucursal(s);
            clear();
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Error refreshDetail() " + e.getMessage());
        }
    }

    //Método para guardar
    public void save() {
        /*VARIABLE QUE MANDAREMOS PARA EL MÉTODO PERSONALIZADO*/
        Usuario us = null;
        /*PARA RECOJER LO QUE RECIBIMOS DEL MÉTODO*/
        Persona per = null;

        FacesMessage mensa;
        Producto pr;
        Date d = new Date();
        try {
            /*RECOJEMOS LA SESIÓN*/
            us = (Usuario) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("Usuario");
            /*MANDAMOS A RECOJER LA PERSONA CORRESPONDIENTE Y POR NDE SU RESPECTIVA SUCURSAL*/
            per = this.detProdEJB.getPersona(us);
            /*SETEAMOS LA ID DE LA SUCURSAL A LA ENTIDAD*/
            this.suc.setId_sucursal(per.getId_sucursal().getId_sucursal());
            /*RECOJEMOS LA SESIÓN Y LA ASIGNAMOS A LA ENTIDAD*/
            us = (Usuario) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("Usuario");
            this.usu = us;

            if (this.detProd.getUnidades_recibidas() > 0) {
                pr = this.detProdEJB.getCosto(prod);

                double pu = pr.getCosto_unitario();
                int cnt = this.detProd.getUnidades_recibidas();
                double valor = (pu * cnt);
                /*SETEAMOS EL RESULTADO AL ATRIBUTO*/
                this.detProd.setValor_en_inv(valor);

                //Fecha
                this.detProd.setFecha_hora(d);
                
                /*SETEAMOS LAS ENTIDADES CORRESPONDIENTES*/
                this.detProd.setId_proveedor(pro);
                this.detProd.setId_producto(prod);
                this.detProd.setId_usuario(usu);
                this.detProd.setId_sucursal(suc);
                detProdEJB.create(detProd);

                if (us.getId_rolesUsuario().getId_rolesUsuario() == 2) {
                    refreshDetail();
                } else if (us.getId_rolesUsuario().getId_rolesUsuario() == 3) {

                } else {
                    refresh();
                }

                msj = "Datos guardados correctamente";
                mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Completado", msj);

            } else {
                msj = "Cantidad recibida no puede ser cero";
                mensa = new FacesMessage(FacesMessage.SEVERITY_WARN, "Informe", msj);
                clear();
                refresh();
            }

        } catch (Exception e) {
            msj = "Error al guardar por " + e.getMessage();
            System.out.println("No guarda por " + e.getMessage());
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", msj);
        }
        FacesContext.getCurrentInstance().addMessage(msj, mensa);
    }

    //Método para eliminar
    public void delete(DetalleProducto id) {
        /*RECOJEMOS LA SESIÓN*/
        Usuario us = (Usuario) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("Usuario");
        FacesMessage mensa;
        try {
            this.detProdEJB.delete(id);
            msj = "Datos eliminados correctamente";

            if (us.getId_rolesUsuario().getId_rolesUsuario() == 2) {
                refreshDetail();
            } else if (us.getId_rolesUsuario().getId_rolesUsuario() == 3) {

            } else {
                refresh();
            }
            mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Completado", msj);
        } catch (Exception e) {
            msj = "Error al eliminar por " + e.getMessage();
            System.out.println("No elimina por " + e.getMessage());
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", msj);
        }
        FacesContext.getCurrentInstance().addMessage(msj, mensa);
    }

    //Método para actualizar
    public void update() {
        /*RECOJEMOS LA SESIÓN*/
        Usuario us = (Usuario) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("Usuario");
        FacesMessage mensa;
        Producto pr;
        try {
            if (this.detProd.getUnidades_recibidas() > 0) {
                //Obtenemos el costo del producto
                pr = this.detProdEJB.getCosto(prod);
                //Asignamos
                double pu = pr.getCosto_unitario();
                int cnt = this.detProd.getUnidades_recibidas();
                //Calculamos el precio total
                double valor = (pu * cnt);
                /*SETEAMOS EL RESULTADO AL ATRIBUTO*/
                this.detProd.setValor_en_inv(valor);

                /*SETEAMOS LAS ENTIDADES CORRESPONDIENTES*/
                this.detProd.setId_sucursal(suc);
                this.detProd.setId_proveedor(pro);
                this.detProd.setId_producto(prod);
                this.detProd.setId_usuario(usu);
                detProdEJB.edit(detProd);

                if (us.getId_rolesUsuario().getId_rolesUsuario() == 2) {
                    refreshDetail();
                } else if (us.getId_rolesUsuario().getId_rolesUsuario() == 3) {

                } else {
                    refresh();
                }
                msj = "Datos modificados correctamente";
                mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Completado", msj);
            } else {
                msj = "Cantidad recibida no puede ser cero";
                mensa = new FacesMessage(FacesMessage.SEVERITY_WARN, "Informe", msj);
                clear();
            }

        } catch (Exception e) {
            msj = "Error al modificados por " + e.getMessage();
            System.out.println("No guarda por " + e.getMessage());
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", msj);
        }
        FacesContext.getCurrentInstance().addMessage(msj, mensa);
    }

    //Método para cargar
    public void find(DetalleProducto id) {
        try {
            this.suc.setId_sucursal(id.getId_sucursal().getId_sucursal());
            this.pro.setId_proveedor(id.getId_proveedor().getId_proveedor());
            this.prod.setId_producto(id.getId_producto().getId_producto());
            this.usu.setId_usuario(id.getId_usuario().getId_usuario());
            //Igualamos el parámetro a la entidad
            this.detProd = id;
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("No carga por " + e.getMessage());
        }
    }
}
