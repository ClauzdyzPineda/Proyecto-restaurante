/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import ejb.ScaPlatilloFacadeLocal;
import entity.ScaPlatillo;
import entity.Tiempo;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

/**
 *
 * @author serafin
 */
@Named(value = "cScaPlatillo")
@SessionScoped
public class CScaPlatillo implements Serializable {

    @EJB(beanName = "splatillo")
    private ScaPlatilloFacadeLocal scaPlaEJB;
    private List<ScaPlatillo> lista;
    private ScaPlatillo scaPla;
    private Tiempo tie;

    private String msj;

    /*RECOJER TODOS LOS RUBROS DE TIEMPO*/
    private String[] tmp;

    public ScaPlatillo getScaPla() {
        return scaPla;
    }

    public List<ScaPlatillo> getLista() {
        this.lista = this.scaPlaEJB.findAll();
        return lista;
    }

    public void setLista(List<ScaPlatillo> lista) {
        this.lista = lista;
    }

    public void setScaPla(ScaPlatillo scaPla) {
        this.scaPla = scaPla;
    }

    public Tiempo getTie() {
        return tie;
    }

    public void setTie(Tiempo tie) {
        this.tie = tie;
    }

    public String[] getTmp() {
        return tmp;
    }

    public void setTmp(String[] tmp) {
        this.tmp = tmp;
    }

    @PostConstruct
    public void init() {
        this.scaPla = new ScaPlatillo();
        this.tie = new Tiempo();
        this.tmp = null;
    }

    public void refresh() {
        try {
            init();
            this.lista = this.scaPlaEJB.findAll();
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("LISTA NO RECONOCIDA");
        }
    }

    public void save() {
        FacesMessage mensa;
        try {
            if (tmp.length > 0) {
                for (int i = 0; i < tmp.length; i++) {
                    this.tie.setId_tiempo(Integer.parseInt(tmp[i]));
                    this.scaPla.setId_tiempo(tie);
                    this.scaPlaEJB.create(scaPla);
                    this.tie = new Tiempo();
                }
                refresh();
                init();
                this.msj = "Registro guardado con éxito";
                mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Informa", msj);
            } else {
                this.msj = "Seleccione al menos un rubro...";
                mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Informa", msj);
            }

        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Error al guardar " + e.getMessage());
            this.msj = "No se ha podido guardar.\n"
                    + "Error: " + e.getMessage();
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Informa", msj);
        }
        FacesContext.getCurrentInstance().addMessage(null, mensa);
    }

    public void update() {
        FacesMessage mensa;
        try {
            this.scaPla.setId_tiempo(tie);
            this.scaPlaEJB.edit(scaPla);
            refresh();
            this.msj = "Registro modificado con éxito";
            mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Informa", msj);
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Error al guardar " + e.getMessage());
            this.msj = "No se ha podido actualizar.\n"
                    + "Error: " + e.getMessage();
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Informa", msj);
        }
        FacesContext.getCurrentInstance().addMessage(null, mensa);
    }

    public void delete(ScaPlatillo id) {
        FacesMessage mensa;
        try {
            System.out.println("EEE" + id.getTipo());
            this.scaPlaEJB.delete(id);
            refresh();
            init();
            this.msj = "Registro eliminado con éxito";
            mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Informa", msj);
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Error al eliminar " + e.getMessage());
            this.msj = "No se ha podido eliminar.\n"
                    + "Error: " + e.getMessage();
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Informa", msj);
        }
        FacesContext.getCurrentInstance().addMessage(null, mensa);
    }

    public void find(ScaPlatillo id) {
        FacesMessage mensa;
         System.out.println("EEE" + id.getTipo());
        try {
            this.tie.setId_tiempo(id.getId_tiempo().getId_tiempo());
            this.scaPla = id;
            this.msj = "Registro cargado con éxito";
            mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Informa", msj);
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Error al cargar " + e.getMessage());
            this.msj = "No se ha podido cargar el registro.\n"
                    + "Error: " + e.getMessage();
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Informa", msj);
        }
        FacesContext.getCurrentInstance().addMessage(null, mensa);
    }

}
