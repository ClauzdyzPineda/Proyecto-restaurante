/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import entity.Usuario;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import javax.faces.context.FacesContext;

/**
 * @author fernando.barrazausam
 *
 * ESTE CONSTROLADOR NOS SIRVE PARA UTILIZAR EL NAVBAR, PARA QUE DEPENDIENDO EL
 * USUARIO REALICE LAS DISTINTAS REDIRECCIONES
 *
 */
@Named(value = "cMenu")
@SessionScoped
public class cMenu implements Serializable {

    private String url;

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String redirect(String url) {
        Usuario usuario = null;
        String carpeta = null;
        String ruta = null;
        try {
            usuario = (Usuario) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("Usuario");

            switch (usuario.getId_rolesUsuario().getId_rolesUsuario()) {
                case 1:
                    carpeta = "AdminSU";
                    break;
                case 2:
                    carpeta = "Admin";
                    break;
                case 3:
                    carpeta = "Users";
                    break;
                default:

                    break;
            }
            switch (url) {
                case "home":
                    ruta = "/views/" + carpeta + "/home?faces-redirect=true";
                    break;
                case "opt1":
                    ruta = "/views/" + carpeta + "/config/vUsers?faces-redirect=true";
                    break;

                case "opt2":
                    ruta = "/views/" + carpeta + "/config/vSucursal?faces-redirect=true";
                    break;

                case "opt3":
                    ruta = "/views/" + carpeta + "/config/vPersonal?faces-redirect=true";
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error " + e.getMessage());
        }
        return ruta;
    }

    public String redirections(String page) {
        Usuario usuario = null;
        String carpeta = null;
        String ruta = null;
        try {
            usuario = (Usuario) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("Usuario");

            switch (usuario.getId_rolesUsuario().getId_rolesUsuario()) {
                case 1:
                    carpeta = "AdminSU";
                    break;
                case 2:
                    carpeta = "Admin";
                    break;
                case 3:
                    carpeta = "Users";
                    break;
                default:

                    break;
            }

            switch (page) {
                /*INVENTARIOS*/
                case "pro":
                    ruta = "/views/" + carpeta + "/Inventarios/Proveedores/viewProveedores?faces-redirect=true";
                    break;
                case "prod":
                    ruta = "/views/" + carpeta + "/Inventarios/Productos/viewProducto?faces-redirect=true";
                    break;
                case "detPro":
                    ruta = "/views/" + carpeta + "/Inventarios/DetalleIngresos/viewDetalleProducto?faces-redirect=true";
                    break;
                case "ped":
                    ruta = "/views/" + carpeta + "/Inventarios/Pedidos/viewPedido?faces-redirect=true";
                    break;
                /*VENTAS*/
                case "vnt":
                    ruta = "/views/" + carpeta + "/Ventas/viewVentas?faces-redirect=true";
                    break;
                /*MENÚ*/
                case "men":
                    ruta = "/views/" + carpeta + "/Menu/Platillos/ListaPlatillos/viewPlatillos?faces-redirect=true";
                    break;                
                case "beb":
                    ruta = "/views/" + carpeta + "/Menu/Otros/Bebidas/viewBebidas?faces-redirect=true";
                    break;
                case "cmp":
                    ruta = "/views/" + carpeta + "/Menu/Otros/Complementos/viewComplementos?faces-redirect=true";
                    break;
                /*OTROS*/
                case "reg":
                    ruta = "/views/" + carpeta + "/Otros/Bitacoras/viewRegistros?faces-redirect=true";
                    break;
                case "movs":
                    ruta = "/views/" + carpeta + "/Otros/Movimientos/viewMovimientos?faces-redirect=true";
                    break;
                case "esf":
                    ruta = "/views/" + carpeta + "/Otros/Estados/viewEstados?faces-redirect=true";
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error " + e.getMessage());
        }
        return ruta;
    }

}
