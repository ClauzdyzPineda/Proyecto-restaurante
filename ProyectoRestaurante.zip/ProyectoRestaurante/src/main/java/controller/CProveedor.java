/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import ejb.ProveedorFacadeLocal;
import entity.Proveedor;
import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Named;

@Named(value = "cProveedor")
@SessionScoped
public class CProveedor implements Serializable {

    @EJB
    private ProveedorFacadeLocal proveedorEJB;
    private Proveedor pro;
    private List<Proveedor> lista;
    String mensa = "";

    public List<Proveedor> getLista() {
        lista = proveedorEJB.findAll();
        return lista;
    }

    public void setLista(List<Proveedor> lista) {
        this.lista = lista;
    }

    public Proveedor getPro() {
        return pro;
    }

    public void setPro(Proveedor pro) {
        this.pro = pro;
    }

    @PostConstruct
    public void init() {
        pro = new Proveedor();
    }

    public void refresh(){
        this.lista = this.proveedorEJB.findAll();
        init();
    }

    public void create() {
        FacesMessage message;
        try {
            proveedorEJB.create(pro);
            init();
            message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Exito", "Datos Guardados");
        } catch (Exception e) {
            message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "Error al guardar");
        }
        FacesContext.getCurrentInstance().addMessage(null, message);
    }

    public void update() {
        FacesMessage message;
        try {
            proveedorEJB.edit(pro);
            init();
            message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Exito", "Datos Modificados");
        } catch (Exception e) {
            message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "Error al Modificar");
        }
        FacesContext.getCurrentInstance().addMessage(null, message);
    }

    public void delete(Proveedor p) {
        FacesMessage message;
        try {
            proveedorEJB.delete(p);
            init();
            message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Exito", "Datos Eliminados");
        } catch (Exception e) {
            message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "Error al Eliminar");
        }
        FacesContext.getCurrentInstance().addMessage(null, message);
    }

    public void find(Proveedor id) {
        try {
            this.pro = this.proveedorEJB.find(id.getId_proveedor());
        } catch (Exception e) {
        }
    }

}
