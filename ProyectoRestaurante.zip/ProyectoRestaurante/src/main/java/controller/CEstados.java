/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import ejb.EstadosFacadeLocal;
import entity.Estados;
import entity.Persona;
import entity.Sucursal;
import entity.Usuario;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

/**
 *
 * @author serafin
 */
@Named(value = "cEstados")
@SessionScoped
public class CEstados implements Serializable {

    @EJB
    private EstadosFacadeLocal estadosEJB;
    private Estados est;
    private List<Estados> lista;

    //Foranea
    private Sucursal suc;
    private Usuario usu;
    //Extras para el GAP
    private double vntnetas;
    private double compratotal;
    private double compraneta;
    private double dispmercad;
    private double utibruta;
    private double costovnt;
    private double gastosop;
    private double utiantesres;
    private double utiantesimp;

    //Atributo para condicionar si es perdida o utilidad
    private int bool;

    //Valores para recojer intervalo de reporte de registros
    private Date date1;
    private Date date2;
    //Listado reporte
    private List<Estados> listReport;

    //Mensaje
    private String msj;

    //Extras
    public List<Estados> getListReport() {
        return listReport;
    }

    public void setListReport(List<Estados> listReport) {
        this.listReport = listReport;
    }

    public Date getDate1() {
        date1 = new Date();
        return date1;
    }

    public void setDate1(Date date1) {
        this.date1 = date1;
    }

    public Date getDate2() {
        date2 = new Date();
        return date2;
    }

    public void setDate2(Date date2) {
        this.date2 = date2;
    }

    public int getBool() {
        return bool;
    }

    public void setBool(int bool) {
        this.bool = bool;
    }

    public double getVntnetas() {
        return vntnetas;
    }

    public void setVntnetas(double vntnetas) {
        this.vntnetas = vntnetas;
    }

    public double getCompratotal() {
        return compratotal;
    }

    public void setCompratotal(double compratotal) {
        this.compratotal = compratotal;
    }

    public double getCompraneta() {
        return compraneta;
    }

    public void setCompraneta(double compraneta) {
        this.compraneta = compraneta;
    }

    public double getDispmercad() {
        return dispmercad;
    }

    public void setDispmercad(double dispmercad) {
        this.dispmercad = dispmercad;
    }

    public double getUtibruta() {
        return utibruta;
    }

    public void setUtibruta(double utibruta) {
        this.utibruta = utibruta;
    }

    public double getCostovnt() {
        return costovnt;
    }

    public void setCostovnt(double costovnt) {
        this.costovnt = costovnt;
    }

    public double getGastosop() {
        return gastosop;
    }

    public void setGastosop(double gastosop) {
        this.gastosop = gastosop;
    }

    public double getUtiantesres() {
        return utiantesres;
    }

    public void setUtiantesres(double utiantesres) {
        this.utiantesres = utiantesres;
    }

    public double getUtiantesimp() {
        return utiantesimp;
    }

    public void setUtiantesimp(double utiantesimp) {
        this.utiantesimp = utiantesimp;
    }

    public Usuario getUsu() {
        return usu;
    }

    //--------
    public void setUsu(Usuario usu) {
        this.usu = usu;
    }

    public Estados getEst() {
        return est;
    }

    public void setEst(Estados est) {
        this.est = est;
    }

    public List<Estados> getLista() {
        this.lista = this.estadosEJB.findAll();
        return lista;
    }

    public void setLista(List<Estados> lista) {
        this.lista = lista;
    }

    public Sucursal getSuc() {
        return suc;
    }

    public void setSuc(Sucursal suc) {
        this.suc = suc;
    }

    @PostConstruct
    public void init() {
        this.est = new Estados();
        this.suc = new Sucursal();
        this.usu = new Usuario();
        gastosop = 0.00;
        vntnetas = 0.00;
        compratotal = 0.00;
        compraneta = 0.00;
        dispmercad = 0.00;
        utibruta = 0.00;
        costovnt = 0.00;
        gastosop = 0.00;
        utiantesres = 0.00;
        utiantesimp = 0.00;
    }

    public void findAll() {
        try {
            this.lista = this.estadosEJB.findAll();
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Error findAll " + e.getMessage());
        }
    }

    public void save() {
        //Creamos Calendar para adquirir dia inicial y final del mes actual
        Calendar calI = Calendar.getInstance();
        Calendar calF = Calendar.getInstance();
        //Formato para obtener primeramente solo la fecha de Calentar
        SimpleDateFormat onlydate = new SimpleDateFormat("dd/MM/yyyy");
        //Formato para sustituir la primera y última hora del día
        SimpleDateFormat dateTime = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

        Usuario us = new Usuario();
        Persona per = new Persona();

        FacesMessage mensa;
        try {
            //Obtenemos el día inicial del mes
            calI.set(Calendar.DAY_OF_MONTH, 1);
            //Obtenemos el día final del mes
            calF.set(Calendar.DAY_OF_MONTH, calF.getActualMaximum(Calendar.DAY_OF_MONTH));

            //Obtenemos la fecha del Calendar y le concatenamos la hora inicial y final de un día
            String diaI = onlydate.format(calI.getTime()) + " " + "00:00:01";
            String diaF = onlydate.format(calF.getTime()) + " " + "23:59:59";

            //Setemoas los valores a los campos
            est.setInicio(dateTime.parse(diaI));
            est.setCierre(dateTime.parse(diaF));

            System.out.println(diaI + " " + diaF);
            System.out.println(est.getInicio() + " " + est.getCierre());

            //Obtenemos las ventas del mes que igual serain las ventas netas
            est.setVentas(estadosEJB.getVnt(est.getInicio(), est.getCierre()));
            //Obtenemos el inventario al inicio del mes
            est.setInv_inicial(estadosEJB.getValInvInit(est.getInicio(), est.getCierre()));
            //Obtenemos las compras del mes
            est.setCompras(estadosEJB.getCompras(est.getInicio(), est.getCierre()));
            //Obtenemos el inventario al final del mes
            est.setInv_final(estadosEJB.getValInvEnd(est.getInicio(), est.getCierre()));

            //Compras totales
            this.compratotal = (est.getCompras() + est.getGst_compras());

            //Compra neta
            this.compraneta = (compratotal - est.getDev_compras());

            //Disponibilidad de mercaderia
            this.dispmercad = (est.getInv_inicial() + compraneta);

            //Costo de ventas
            this.costovnt = (dispmercad - est.getInv_final());

            //Utilidad bruta
            this.utibruta = (est.getVentas() - costovnt);

            //Gastos totales
            this.gastosop = (est.getG_adm() + est.getG_financ() + est.getG_ventas());

            //Utilidad antes de reserva 
            this.utiantesres = (utibruta - gastosop);

            /*Condición que indica que si es negativa o como minimo a la quinta parte 
            de nuestra capital social. El cual fue detallado como $2000 el inicial, 
            su 4ta parte son $ 400, si la utilidad neta pasa de eso se calculara Reserva*/
            if (utiantesres >= 400.00) {
                //Calculamos la reserva legal
                this.est.setReserva(utiantesres * 0.07);
            } else {
                this.est.setReserva(0.00);
            }

            //Utilidad antes de ISR
            this.utiantesimp = (utiantesres - est.getReserva());

            //Gastos totales del mes
            double gastos = (compraneta + gastosop);

            //Calculamos el ISR
            if (est.getVentas() > gastos) {
                if (est.getVentas() < 150000) {
                    this.est.setIsr(utiantesimp * 0.25);
                } else if (est.getVentas() >= 150000) {
                    this.est.setIsr(utiantesimp * 0.35);
                }
            } else {
                this.est.setIsr(0.00);
            }

            //Utilidad del ejercicio
            this.est.setUtilidad(utiantesimp - est.getIsr());

            /*RECOJEMOS LA SESIÓN*/
            us = (Usuario) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("Usuario");
            /*MANDAMOS A RECOJER LA PERSONA CORRESPONDIENTE Y POR NDE SU RESPECTIVA SUCURSAL*/
            per = this.estadosEJB.getPersona(us);
            /*SETEAMOS LA ID DE LA SUCURSAL A LA ENTIDAD*/

 /*ESTO INDICA LA SUCURSAL DESDE DONDE SE CREO, MAS NO QUE ES EL ESTADO DE LA QUE SE DETALLA.
            ES UN ESTADO DE RESULTADO GENERAL PARA TODAS LAS SUCURSALES*/
            this.suc.setId_sucursal(per.getId_sucursal().getId_sucursal());
            this.usu = us;

            this.est.setId_sucursal(suc);
            this.est.setId_usuario(usu);
            this.estadosEJB.create(est);

            this.msj = "Registro guardado con éxito";
            mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Informe", msj);
            init();
            findAll();
        } catch (Exception e) {
            e.printStackTrace();
            this.msj = "Algo ha fallado...";
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Informe", msj + " " + e.getMessage());
        }

        FacesContext.getCurrentInstance().addMessage(msj, mensa);
    }

    public void update() {
        FacesMessage mensa;
        try {
            this.est.setId_sucursal(suc);
            this.est.setId_usuario(usu);

            //Compras totales
            this.compratotal = (est.getCompras() + est.getGst_compras());

            //Compra neta
            this.compraneta = (compratotal - est.getDev_compras());

            //Disponibilidad de mercaderia
            this.dispmercad = (est.getInv_inicial() + compraneta);

            //Costo de ventas
            this.costovnt = (dispmercad - est.getInv_final());

            //Utilidad bruta
            this.utibruta = (est.getVentas() - costovnt);

            //Gastos totales
            this.gastosop = (est.getG_adm() + est.getG_financ() + est.getG_ventas());

            //Utilidad antes de reserva 
            this.utiantesres = (utibruta - gastosop);

            /*Condición que indica que si es negativa o como minimo a la quinta parte 
            de nuestra capital social. El cual fue detallado como $2000 el inicial, 
            su 4ta parte son $ 400, si la utilidad neta pasa de eso se calculara Reserva*/
            if (utiantesres >= 400.00) {
                //Calculamos la reserva legal
                this.est.setReserva(utiantesres * 0.07);
            } else {
                this.est.setReserva(0.00);
            }

            //Utilidad antes de ISR
            this.utiantesimp = (utiantesres - est.getReserva());

            //Gastos totales del mes
            double gastos = (compraneta + gastosop);

            //Calculamos el ISR
            if (est.getVentas() > gastos) {
                if (est.getVentas() < 150000) {
                    this.est.setIsr(utiantesimp * 0.25);
                } else if (est.getVentas() >= 150000) {
                    this.est.setIsr(utiantesimp * 0.35);
                }
            } else {
                this.est.setIsr(0.00);
            }

            //Utilidad del ejercicio
            this.est.setUtilidad(utiantesimp - est.getIsr());

            //Guardamos los cambios
            this.estadosEJB.edit(est);

            this.msj = "Registro modificado con éxito";
            mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Informe", msj);
            init();
            findAll();
            reports();
        } catch (Exception e) {
            e.printStackTrace();
            this.msj = "Algo ha fallado...";
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Informe", msj + " " + e.getMessage());
        }

        FacesContext.getCurrentInstance().addMessage(msj, mensa);
    }

    //Encontrar la información de un registro
    public void find(Estados id) {
        try {
            //Cargamos las entidades principales
            this.suc.setId_sucursal(id.getId_sucursal().getId_sucursal());
            this.usu.setId_usuario(id.getId_usuario().getId_usuario());
            this.est = id;

            //Compras totales
            this.compratotal = (est.getCompras() + est.getGst_compras());

            //Compra neta
            this.compraneta = (compratotal - est.getDev_compras());

            //Disponibilidad de mercaderia
            this.dispmercad = (est.getInv_inicial() + compraneta);

            //Costo de ventas
            this.costovnt = (dispmercad - est.getInv_final());

            //Utilidad bruta
            this.utibruta = (est.getVentas() - costovnt);

            //Gastos totales
            this.gastosop = (est.getG_adm() + est.getG_financ() + est.getG_ventas());

            //Utilidad antes de reserva 
            this.utiantesres = (utibruta - gastosop);

            //Utilidad antes de ISR
            this.utiantesimp = (utiantesres - est.getReserva());

            if (est.getUtilidad() > 0) {
                bool = 1;
            } else {
                bool = 0;
            }

        } catch (Exception e) {
            e.printStackTrace();;
            System.err.println("Error al encontrar registro " + e.getMessage());
        }
    }

    public void delete(Estados id) {
        FacesMessage mensa;
        try {
            this.estadosEJB.delete(id);
            this.msj = "Registro eliminado con éxito";
            mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Informe", msj);
            init();
            findAll();
            reports();
        } catch (Exception e) {
            e.printStackTrace();
            this.msj = "Algo ha fallado...";
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Informe", msj + " " + e.getMessage());
        }
        FacesContext.getCurrentInstance().addMessage(msj, mensa);
    }

    //Método apra calcular en tiempo real el total de gastos de operación, al crear un estado
    public void sumGstOp() {
        this.gastosop = (est.getG_adm() + est.getG_financ() + est.getG_ventas());

    }

    //Re calcular ventas del mes
    public void sumVnt() {
        try {
            est.setVentas(0.00);
            //Obtenemos las ventas del mes que igual serain las ventas netas
            est.setVentas(estadosEJB.getVnt(est.getInicio(), est.getCierre()));
            newValues();
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Error al recalcular ventas " + e.getMessage());
        }
    }

    //Recalcular inv inicial
    public void invIni() {
        try {
            est.setInv_inicial(0.00);
            //Obtenemos el inventario al inicio del mes
            est.setInv_inicial(estadosEJB.getValInvInit(est.getInicio(), est.getCierre()));
            newValues();
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Error al recalcular inv ini " + e.getMessage());
        }
    }

    //re calcular inv final
    public void invFin() {
        try {
            est.setInv_final(0.00);
            //Obtenemos el inventario al final del mes
            est.setInv_final(estadosEJB.getValInvEnd(est.getInicio(), est.getCierre()));
            newValues();
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Error al recalcular inv fin " + e.getMessage());
        }
    }

    //Recalcular compras
    public void sumCmp() {
        try {
            est.setCompras(0.00);
            //Obtenemos las compras del mes
            est.setCompras(estadosEJB.getCompras(est.getInicio(), est.getCierre()));
            newValues();
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Error al recalcular compras " + e.getMessage());
        }
    }

    public void newValues() {
        try {
            //Compras totales
            this.compratotal = (est.getCompras() + est.getGst_compras());

            //Compra neta
            this.compraneta = (compratotal - est.getDev_compras());

            //Disponibilidad de mercaderia
            this.dispmercad = (est.getInv_inicial() + compraneta);

            //Costo de ventas
            this.costovnt = (dispmercad - est.getInv_final());

            //Utilidad bruta
            this.utibruta = (est.getVentas() - costovnt);

            //Gastos totales
            this.gastosop = (est.getG_adm() + est.getG_financ() + est.getG_ventas());

            //Utilidad antes de reserva 
            this.utiantesres = (utibruta - gastosop);

            /*Condición que indica que si es negativa o como minimo a la quinta parte 
            de nuestra capital social. El cual fue detallado como $2000 el inicial, 
            su 4ta parte son $ 400, si la utilidad neta pasa de eso se calculara Reserva*/
            if (utiantesres >= 400.00) {
                //Calculamos la reserva legal
                this.est.setReserva(utiantesres * 0.07);
            } else {
                this.est.setReserva(0.00);
            }

            //Utilidad antes de ISR
            this.utiantesimp = (utiantesres - est.getReserva());

            //Gastos totales del mes
            double gastos = (compraneta + gastosop);

            /*Calculamos el ISR, se calcula solo si los ingresos son mayores a los egresos
            entonces calculamos ISR, de lo contrario no*/
            if (est.getVentas() > gastos) {
                if (est.getVentas() < 150000) {
                    this.est.setIsr(utiantesimp * 0.25);
                } else if (est.getVentas() >= 150000) {
                    this.est.setIsr(utiantesimp * 0.35);
                }
            } else {
                this.est.setIsr(0.00);
            }

            //Utilidad del ejercicio
            this.est.setUtilidad(utiantesimp - est.getIsr());
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error newValues " + e.getMessage());
        }
    }

    public void reports() {
        try {
            this.listReport = this.estadosEJB.getReport(this.date1, this.date2);
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("ERROR AL GENERAR!!!" + e.getMessage());
        }
    }

    public void cleanReport() {
        try {
            date1 = new Date();
            date2 = new Date();
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("ERROR AL limpiar cleanReport!!!" + e.getMessage());
        }
    }

}
