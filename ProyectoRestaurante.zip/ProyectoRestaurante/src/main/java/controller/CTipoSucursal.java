/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import ejb.TipoSucursalFacadeLocal;
import entity.TipoSucursal;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

/**
 *
 * @author eddie.hernandezusam
 */
@Named(value = "cTipoSucursal")
@SessionScoped
public class CTipoSucursal implements Serializable {

    @EJB
    private TipoSucursalFacadeLocal TsursalEJB;
    private TipoSucursal tipSuc;
    private List<TipoSucursal> lista;

    private String msj;

    public TipoSucursal getTipSuc() {
        return tipSuc;
    }

    public void setTipSuc(TipoSucursal tipSuc) {
        this.tipSuc = tipSuc;
    }

    public List<TipoSucursal> getLista() {
        this.lista = this.TsursalEJB.findAll();
        return lista;
    }

    public void setLista(List<TipoSucursal> lista) {
        this.lista = lista;
    }

    @PostConstruct
    public void init() {
        tipSuc = new TipoSucursal();
    }

    public void clear() {
        init();
    }

    public void refresh() {
        this.lista = this.TsursalEJB.findAll();
        init();
    }

    public void save() {
        try {
            TsursalEJB.create(tipSuc);
            this.msj = "Registro guardado con éxito ";
            FacesMessage mensaje = new FacesMessage(FacesMessage.SEVERITY_INFO, "INFORME", msj);
            FacesContext.getCurrentInstance().addMessage(null, mensaje);
            clear();
        } catch (Exception e) {
            e.printStackTrace();
            this.msj = "Error Grave : " + e.getMessage();
            FacesMessage mensaje = new FacesMessage(FacesMessage.SEVERITY_ERROR, "ALERTA", msj);
            FacesContext.getCurrentInstance().addMessage(null, mensaje);
        }
    }

    public void delete(TipoSucursal id) {
        try {
            TsursalEJB.delete(id);
            this.msj = "Registro Eliminado con exito";
            FacesMessage mensaje = new FacesMessage(FacesMessage.SEVERITY_INFO, "INFORME", msj);
            FacesContext.getCurrentInstance().addMessage(null, mensaje);
        } catch (Exception e) {
            e.printStackTrace();
            this.msj = "Error Grave : " + e.getMessage();
            FacesMessage mensaje = new FacesMessage(FacesMessage.SEVERITY_ERROR, "ALERTA", msj);
            FacesContext.getCurrentInstance().addMessage(null, mensaje);
        }
    }

    public void update() {
        try {
            this.TsursalEJB.edit(tipSuc);
            this.msj = "Registro Editado Correctamente";
            FacesMessage mensaje = new FacesMessage(FacesMessage.SEVERITY_INFO, "ALERTA", msj);
            FacesContext.getCurrentInstance().addMessage(null, mensaje);
        } catch (Exception e) {
            e.printStackTrace();
            this.msj = "Error Grave : " + e.getMessage();
            FacesMessage mensaje = new FacesMessage(FacesMessage.SEVERITY_ERROR, "ALERTA", msj);
            FacesContext.getCurrentInstance().addMessage(null, mensaje);
        }
    }

    public void find(TipoSucursal id) {
        FacesMessage mensa;
        try {
            this.tipSuc = id;
            this.msj = "Registro cargado correctamente";
            mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "INFORME", msj);
            FacesContext.getCurrentInstance().addMessage(null, mensa);
        } catch (Exception e) {
            e.printStackTrace();
            this.msj = "No se pudo cargar la información...";
            System.err.println("Error al cargar registro : " + e.getMessage());
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "ALERTA", msj);

        }
        FacesContext.getCurrentInstance().addMessage(null, mensa);
    }
}
