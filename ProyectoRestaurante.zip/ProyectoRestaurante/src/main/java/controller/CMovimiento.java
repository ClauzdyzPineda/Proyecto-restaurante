/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import ejb.MovimientoFacadeLocal;
import entity.Movimiento;
import entity.Persona;
import entity.Sucursal;
import entity.Usuario;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

/**
 *
 * @author fernando.barrazausam
 */
@Named(value = "cMovimiento")
@SessionScoped
public class CMovimiento implements Serializable {

    @EJB
    private MovimientoFacadeLocal movEJB;
    private Movimiento mov;
    private List<Movimiento> lista;

    //Atributos especiales apra usuario nivel 2
    private List<Movimiento> listUser;

    /*FORANEAS*/
    private Sucursal suc;

    /*MENSAJE*/
    private String msj;

    public List<Movimiento> getListUser() {
        Usuario us = (Usuario) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("Usuario");

        /*MANDAMOS A RECOJER LA PERSONA CORRESPONDIENTE Y POR NDE SU RESPECTIVA SUCURSAL*/
        Persona per = this.movEJB.getPersona(us);
        /*SETEAMOS LA ID DE LA SUCURSAL A LA ENTIDAD*/
        Sucursal s = new Sucursal();
        s.setId_sucursal(per.getId_sucursal().getId_sucursal());
        this.listUser = this.movEJB.getListSucursal(s);
        return listUser;
    }

    public void setListUser(List<Movimiento> listUser) {
        this.listUser = listUser;
    }

    public Movimiento getMov() {
        return mov;
    }

    public void setMov(Movimiento mov) {
        this.mov = mov;
    }

    public List<Movimiento> getLista() {
        this.lista = this.movEJB.findAll();
        return lista;
    }

    public void setLista(List<Movimiento> lista) {
        this.lista = lista;
    }

    public Sucursal getSuc() {
        return suc;
    }

    public void setSuc(Sucursal suc) {
        this.suc = suc;
    }

    @PostConstruct
    public void init() {
        this.mov = new Movimiento();
        this.suc = new Sucursal();
    }

    public void refreshUserLis() {
        try {
            Usuario us = (Usuario) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("Usuario");

            /*MANDAMOS A RECOJER LA PERSONA CORRESPONDIENTE Y POR NDE SU RESPECTIVA SUCURSAL*/
            Persona per = this.movEJB.getPersona(us);
            /*SETEAMOS LA ID DE LA SUCURSAL A LA ENTIDAD*/
            Sucursal s = new Sucursal();
            s.setId_sucursal(per.getId_sucursal().getId_sucursal());
            this.listUser = this.movEJB.getListSucursal(s);
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Error refreshUserLis " + e.getMessage());
        }
    }

    public void refresh() {
        try {
            this.lista = this.movEJB.findAll();
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Error refresh " + e.getMessage());
        }
    }

    public void save() {
        /*VARIABLE QUE MANDAREMOS PARA EL MÉTODO PERSONALIZADO*/
        Usuario us = new Usuario();
        /*PARA RECOJER LO QUE RECIBIMOS DEL MÉTODO*/
        Persona per = new Persona();
        FacesMessage mensa;
        try {
            /*RECOJEMOS LA SESIÓN*/
            us = (Usuario) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("Usuario");
            /*MANDAMOS A RECOJER LA PERSONA CORRESPONDIENTE Y POR NDE SU RESPECTIVA SUCURSAL*/
            per = this.movEJB.getPersona(us);
            /*SETEAMOS LA ID DE LA SUCURSAL A LA ENTIDAD*/
            this.suc.setId_sucursal(per.getId_sucursal().getId_sucursal());
            this.mov.setId_sucursal(suc);
            this.movEJB.create(mov);
            init();
            refresh();
            this.msj = "Registro modificado con  éxito";
            mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Operación completa", msj);

        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Error al modificar " + e.getMessage());
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Operación fallida", msj);
        }
        FacesContext.getCurrentInstance().addMessage(msj, mensa);
    }

    public void update() {
        FacesMessage mensa;
        try {
            this.mov.setId_sucursal(suc);
            this.movEJB.edit(mov);
            init();
            refresh();
            this.msj = "Registro modificado con  éxito";
            mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Operación completa", msj);

        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Error al modificar " + e.getMessage());
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Operación fallida", msj);
        }
        FacesContext.getCurrentInstance().addMessage(msj, mensa);
    }

    public void find(Movimiento id) {
        FacesMessage mensa;
        try {
            this.suc.setId_sucursal(id.getId_sucursal().getId_sucursal());
            this.mov = id;
            this.msj = "Registro modificado con  éxito";
            mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Operación completa", msj);

        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Error al modificar " + e.getMessage());
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Operación fallida", msj);
        }
        FacesContext.getCurrentInstance().addMessage(msj, mensa);
    }

    public void delete(Movimiento id) {
        FacesMessage mensa;
        try {
            this.movEJB.delete(id);
            this.msj = "Registro eliminado con  éxito";
            mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Operación completa", msj);
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Error al eliminar " + e.getMessage());
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Operación fallida", msj);
        }
        FacesContext.getCurrentInstance().addMessage(msj, mensa);
    }

}
