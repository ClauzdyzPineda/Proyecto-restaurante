/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import entity.DetallePlatillo;
import entity.Platillo;
import entity.Producto;
import ejb.DetallePlatilloFacadeLocal;
import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

@Named(value = "cDetallePlatillo")
@SessionScoped
public class CDetallePlatillo implements Serializable {

    @EJB
    private DetallePlatilloFacadeLocal detplaEJB;
    private DetallePlatillo detPla;
    private List<DetallePlatillo> lista;
    private String msj = "";

    /*ARRAY PARA JALAR MUCHOS INGREDIENTES.*/
    private String[] ingredientes;

    /*FORANEAS*/
    private Platillo pla;
    private Producto pro;

    public DetallePlatillo getDetPla() {
        return detPla;
    }

    public void setDetPla(DetallePlatillo detPla) {
        this.detPla = detPla;
    }

    public List<DetallePlatillo> getLista() {
        this.lista = this.detplaEJB.findAll();
        return lista;
    }

    public void setLista(List<DetallePlatillo> lista) {
        this.lista = lista;
    }

    public Platillo getPla() {
        return pla;
    }

    public void setPla(Platillo pla) {
        this.pla = pla;
    }

    public Producto getPro() {
        return pro;
    }

    public void setPro(Producto pro) {
        this.pro = pro;
    }

    public String[] getIngredientes() {
        return ingredientes;
    }

    public void setIngredientes(String[] ingredientes) {
        this.ingredientes = ingredientes;
    }

    @PostConstruct
    public void init() {
        this.detPla = new DetallePlatillo();
        this.pla = new Platillo();
        this.pro = new Producto();
        this.ingredientes = null;
    }

    public void refresh() {
        this.lista = detplaEJB.findAll();
        init();
    }

    public void create() {
        FacesMessage mensa;
        try {
            if (ingredientes.length > 0) {
                for (int i = 0; i < ingredientes.length; i++) {
                    this.pro.setId_producto(Integer.parseInt(ingredientes[i]));
                    this.detPla.setId_producto(pro);
                    this.detPla.setId_platillo(pla);
                    this.detplaEJB.create(detPla);

                    this.pro = new Producto();
                }
                msj = "Ingredientes añadidos con éxito";
                mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Completado", msj);
            } else {
                msj = "Seleccione al menos un ingrediente";
                mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Completado", msj);
            }

            init();
            refresh();
        } catch (Exception e) {
            msj = "Error al guardar los datos";
            System.out.println("Error" + e.getMessage());
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", msj);
        }
        FacesContext.getCurrentInstance().addMessage(null, mensa);
    }

    public void delete(DetallePlatillo dp) {
        FacesMessage mensa;
        try {
            detplaEJB.delete(dp);
            msj = "Datos eliminados correctamente";
            mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Completado", msj);
        } catch (Exception e) {
            msj = "Error al Eliminar los datos";
            System.out.println("Error" + e.getMessage());
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", msj);
        }
        FacesContext.getCurrentInstance().addMessage(null, mensa);
    }

    public void update() {
        FacesMessage mensa = null;
        try {
            detPla.setId_producto(pro);
            detPla.setId_platillo(pla);
            detplaEJB.edit(detPla);
            init();
            refresh();
            msj = "Datos actualizados";
            mensa = new FacesMessage(FacesMessage.SEVERITY_INFO, "Informe", msj);
        } catch (Exception e) {
            msj = "Error al Actualizar los datos";
            System.out.println("Error" + e.getMessage());
            mensa = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", msj);
        }
        FacesContext.getCurrentInstance().addMessage(null, mensa);
    }

    public void find(DetallePlatillo dp) {
        try {
            this.pla.setId_platillo(dp.getId_platillo().getId_platillo());
            this.pro.setId_producto(dp.getId_producto().getId_producto());
            this.detPla = dp;
        } catch (Exception e) {
            System.out.println("Error" + e.getMessage());
        }
    }

}
