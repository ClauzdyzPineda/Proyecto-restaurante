/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "tbDetalleVenta")
public class DetalleVenta implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id_detalleventa;

    @ManyToOne
    @JoinColumn(name = "id_platillo", referencedColumnName = "id_platillo")
    private Platillo id_platillo;

    @ManyToOne
    @JoinColumn(name = "id_bebida", referencedColumnName = "id_bebida")
    private Bebida id_bebida;

    @ManyToOne
    @JoinColumn(name = "id_complemento", referencedColumnName = "id_complemento")
    private Complemento id_complemento;

    @Column(name = "precio_orden")
    private double precio_orden;

    @ManyToOne
    @JoinColumn(name = "id_venta", referencedColumnName = "id_venta")
    private Venta id_venta;

    public int getId_detalleventa() {
        return id_detalleventa;
    }

    public void setId_detalleventa(int id_detalleventa) {
        this.id_detalleventa = id_detalleventa;
    }

    public Platillo getId_platillo() {
        return id_platillo;
    }

    public void setId_platillo(Platillo id_platillo) {
        this.id_platillo = id_platillo;
    }

    public Bebida getId_bebida() {
        return id_bebida;
    }

    public void setId_bebida(Bebida id_bebida) {
        this.id_bebida = id_bebida;
    }

    public Complemento getId_complemento() {
        return id_complemento;
    }

    public void setId_complemento(Complemento id_complemento) {
        this.id_complemento = id_complemento;
    }

    public double getPrecio_orden() {
        return precio_orden;
    }

    public void setPrecio_orden(double precio_orden) {
        this.precio_orden = precio_orden;
    }

    public Venta getId_venta() {
        return id_venta;
    }

    public void setId_venta(Venta id_venta) {
        this.id_venta = id_venta;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 61 * hash + this.id_detalleventa;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final DetalleVenta other = (DetalleVenta) obj;
        if (this.id_detalleventa != other.id_detalleventa) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "DetalleVenta{" + "id_detalleventa=" + id_detalleventa + '}';
    }

    public DetalleVenta() {
    }

}
