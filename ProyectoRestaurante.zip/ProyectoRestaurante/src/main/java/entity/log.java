/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;


public class log {
//    
//    private int id_usuario;
//    private int id_persona;
//    private int id_sucursal;
//    private int id_tipoSucursal;
//
//    public int getId_usuario() {
//        return id_usuario;
//    }
//
//    public void setId_usuario(int id_usuario) {
//        this.id_usuario = id_usuario;
//    }
//
//    public int getId_persona() {
//        return id_persona;
//    }
//
//    public void setId_persona(int id_persona) {
//        this.id_persona = id_persona;
//    }
//
//    public int getId_sucursal() {
//        return id_sucursal;
//    }
//
//    public void setId_sucursal(int id_sucursal) {
//        this.id_sucursal = id_sucursal;
//    }
//
//    public int getId_tipoSucursal() {
//        return id_tipoSucursal;
//    }
//
//    public void setId_tipoSucursal(int id_tipoSucursal) {
//        this.id_tipoSucursal = id_tipoSucursal;
//    }
//    
    
    
}
