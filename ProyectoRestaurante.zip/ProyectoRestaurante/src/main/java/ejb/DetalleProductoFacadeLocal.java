/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import entity.DetalleProducto;
import entity.Persona;
import entity.Producto;
import entity.Sucursal;
import entity.Usuario;
import java.util.List;
import javax.ejb.Local;

@Local
public interface DetalleProductoFacadeLocal {

    void create(DetalleProducto det);

    void edit(DetalleProducto det);

    void delete(DetalleProducto det);

    List<DetalleProducto> findAll();

    DetalleProducto find(Object id);
    
    /*OBTENER COSTO DEL PRODUCTO*/
    Producto getCosto(Producto id);
    
    /*RECOJER LA SUCURSAL EN SESIÓN*/
    Persona getPersona(Usuario us);
    
    List<DetalleProducto> getDetProSucursal(Sucursal suc);
}
