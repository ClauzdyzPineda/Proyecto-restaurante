/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import entity.DetallePlatillo;
import entity.Platillo;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

@Stateless
public class PlatilloFacade extends AbstractFacade<Platillo> implements PlatilloFacadeLocal {

    @PersistenceContext(unitName = "pvb")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public PlatilloFacade() {
        super(Platillo.class);
    }

    @Override
    public List<DetallePlatillo> getIngredientes(Platillo pl) {
        List<DetallePlatillo> lista = null;
        String sql = null;
        try {
            System.out.println(pl.getId_platillo() + "xxxddd");
            sql = "SELECT i FROM DetallePlatillo i WHERE i.id_platillo = ?1";
            Query q = em.createQuery(sql);
            q.setParameter(1, pl);

            lista = q.getResultList();
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error grave PlatilloFacade");
        }
        return lista;
    }

}
