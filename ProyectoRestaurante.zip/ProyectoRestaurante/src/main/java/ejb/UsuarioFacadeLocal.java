/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import entity.Usuario;
import entity.log;
import java.util.List;
import javax.ejb.Local;

@Local
public interface UsuarioFacadeLocal {

    void create(Usuario usuario);

    List<Usuario> findAll();

    void delete(Usuario usuario);

    void edit(Usuario usuario);

    Usuario find(Object id);

    /*Función para llevar a cabo el logeo*/
    Usuario login(Usuario us);
    
//    List<log> loginRL(Usuario us);

}
