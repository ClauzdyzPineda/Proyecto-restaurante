/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import entity.Pedido;
import entity.Persona;
import entity.Producto;
import entity.Sucursal;
import entity.Usuario;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

@Stateless
public class PedidoFacade extends AbstractFacade<Pedido> implements PedidoFacadeLocal {

    @PersistenceContext(unitName = "pvb")

    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public PedidoFacade() {
        super(Pedido.class);
    }

    /*RECOJER PERSONA POR ID PARA POSTERIORMENTE RECOJER LA SUCURSAL*/
    @Override
    public Persona getPersona(Usuario us) {
        List<Persona> lista = null;
        String sql = null;
        Persona per = null;
        try {
            sql = "SELECT p FROM Persona p WHERE p.id_persona = ?1";
            Query q = em.createQuery(sql);

            q.setParameter(1, us.getId_persona().getId_persona());

            lista = q.getResultList();

            if (!lista.isEmpty()) {
                per = lista.get(0);
            } else {
                System.err.println("NO SE EJECUTO QUERY PEDIDO FACADE");
            }

        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("ERROR GRAVE");
        }
        return per;
    }

    //Lista de pedidos por sucursal
    @Override
    public List<Pedido> getPedSucursal(Sucursal s) {
        List<Pedido> list = null;
        String sql = "";
        try {
            sql = "SELECT p FROM Pedido p WHERE p.id_sucursal = ?1";
            Query q = em.createQuery(sql);
            q.setParameter(1, s);

            if (q.getResultList() != null) {
                list = q.getResultList();
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("ERROR getPedSucursal " + e.getMessage());
        }
        return list;
    }

    @Override
    public double getValor_Pro(int pro) {
        double val = 0.00;
        Producto p = new Producto();
        String sql = "";
        try {
            sql = "SELECT p FROM Producto p WHERE p.id_producto = ?1";
            Query q = em.createQuery(sql);
            q.setParameter(1, pro);

            if (q.getResultList() != null) {
                List<Producto> list = q.getResultList();
                if (!list.isEmpty()) {
                    p = list.get(0);
                    val = p.getCosto_unitario();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Error getValor_Pro " + e.getMessage());
        }
        return val;
    }

}
