/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import entity.DetalleProducto;
import entity.DetalleVenta;
import entity.Persona;
import entity.Producto;
import entity.RegistrosInicio;
import entity.Usuario;
import entity.Venta;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TemporalType;

@Stateless
public class RegistroInicioFacade extends AbstractFacade<RegistrosInicio> implements RegistroInicioFacadeLocal {

    @PersistenceContext(unitName = "pvb")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public RegistroInicioFacade() {
        super(RegistrosInicio.class);
    }

    /*RECOJER PERSONA POR ID PARA POSTERIORMENTE RECOJER LA SUCURSAL*/
    @Override
    public Persona getPersona(Usuario us) {
        List<Persona> lista = null;
        String sql = null;
        Persona per = null;
        try {
            sql = "SELECT p FROM Persona p WHERE p.id_persona = ?1";
            Query q = em.createQuery(sql);

            q.setParameter(1, us.getId_persona().getId_persona());

            lista = q.getResultList();

            if (!lista.isEmpty()) {
                per = lista.get(0);

            } else {
                System.err.println("NO SE EJECUTO QUERY PEDIDO FACADE");
            }

        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("ERROR GRAVE");
        }
        return per;
    }

    //Obtener el total de inventario en unidades al momento
    @Override
    public int getInvReg() {
        int value = 0;
        String sql = "";
        try {
            sql = "SELECT SUM(p.existencias) FROM Producto p WHERE p.tipo = 'A' or p.tipo = 'B' or p.tipo = 'C'";
            Query q = em.createQuery(sql);

            List<Long> l = q.getResultList();
            Long lng = l.get(0);
            value = lng.intValue();  
            System.out.println(value);
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("ERROR " + e.getMessage());
        }
        return value;
    }
    
    @Override
    public double getValorInv(){
        double value = 0.00;
        List<Producto> lista = new ArrayList<>();
        Producto p = new Producto();
        try {
            String sql = "SELECT p FROM Producto p WHERE p.tipo = 'A' or p.tipo = 'B' or p.tipo = 'C'";
            Query q = em.createQuery(sql);
            lista = q.getResultList();            
            
            if(!lista.isEmpty()){
                for (int i = 0; i < lista.size(); i++) {
                    p = lista.get(i);
                    value += (p.getExistencias() * p.getCosto_unitario());                    
                }
                System.out.println("TOTAL " + value);
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("ERROR AL EJECUTAR QUERY getValotInv " + e.getMessage());
        }
        
        return value;
    }
    
//    /*PARA OBTENER EL REGISTO DE X TIPOP*/
//SELECT * FROM tbproducto WHERE TIPO = 'A' or tipo = 'B'  or tipo = 'C';
//
///*ENCONTRAR LA VENTA TOTAL ENTRE HORAS*/
//select SUM(venta_total) from tbventa where date(fecha_hora) between '2020-04-08' and '2020-04-09'
    
    

    //VENTAS DEL DÍA
    @Override
    public List<Venta> getTodayVnt(Date d1, Date d2) {
        List<Venta> lista = null;
        String sql = "";
        try {
            sql = "SELECT v FROM Venta v WHERE v.fecha_hora BETWEEN :d1 and :d2 order by v.fecha_hora ASC";

            Query q = em.createQuery(sql);

            q.setParameter("d1", d1, TemporalType.TIMESTAMP);
            q.setParameter("d2", d2, TemporalType.TIMESTAMP);
            lista = q.getResultList();

            if (!lista.isEmpty()) {
                System.out.println("LLENAAA");
            } else {
                System.out.println("VACIAAA");
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("ERROR GRAVE " + e.getMessage());
        }

        return lista;
    }

    //COMPRAS DEL DÍA
    @Override
    public List<DetalleProducto> getTodayDet(Date d1, Date d2) {
        List<DetalleProducto> lista = null;
        String sql = "";
        try {
            sql = "SELECT d FROM DetalleProducto d WHERE d.fecha_hora BETWEEN :d1 and :d2 order by d.fecha_hora ASC";

            Query q = em.createQuery(sql);

            q.setParameter("d1", d1, TemporalType.TIMESTAMP);
            q.setParameter("d2", d2, TemporalType.TIMESTAMP);
            lista = q.getResultList();

            if (!lista.isEmpty()) {
                System.out.println("LLENAAA");
            } else {
                System.out.println("VACIAAA");
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("ERROR GRAVE " + e.getMessage());
        }

        return lista;
    }

    
    //Recojer el detalle de la venta
    @Override
    public List<DetalleVenta> getDetail(Venta ven) {
        List<DetalleVenta> lista = null;
        String sql = "";

        try {
            sql = "SELECT d from DetalleVenta d WHERE d.id_venta = ?1";
            Query q = em.createQuery(sql);
            q.setParameter(1, ven);

            lista = q.getResultList();

            if (!lista.isEmpty()) {
                System.out.println("SI");
            } else {
                System.out.println("NO");
            }

        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("ERROR DE QUERY " + e.getMessage());
        }
        return lista;
    }

}
