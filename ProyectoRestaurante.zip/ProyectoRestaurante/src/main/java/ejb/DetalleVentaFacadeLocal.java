/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import entity.Bebida;
import entity.Complemento;
import entity.DetallePlatillo;
import entity.DetalleVenta;
import entity.Platillo;
import entity.Producto;
import java.util.List;
import javax.ejb.Local;

@Local
public interface DetalleVentaFacadeLocal {

    void create(DetalleVenta detalleVenta);

    List<DetalleVenta> findAll();

    void edit(DetalleVenta detalleVenta);

    void delete(DetalleVenta detalleVenta);

    DetalleVenta find(Object id);

    Platillo getPlatillo(Platillo p);

    Bebida getBebida(Bebida b);

    Complemento getComplemento(Complemento c);
    
    List<DetallePlatillo> getDetailList(Platillo pla);
    
    Producto getProducto(DetallePlatillo d);

}
