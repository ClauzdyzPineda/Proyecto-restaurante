/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import entity.Persona;
import entity.Sucursal;
import entity.Usuario;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

@Stateless
public class PersonaFacade extends AbstractFacade<Persona> implements PersonaFacadeLocal {

    @PersistenceContext(unitName = "")

    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public PersonaFacade() {
        super(Persona.class);
    }

    //Recojer lista con registros de una sucursal en concreto
    @Override
    public List<Persona> getPerSucursal(Sucursal s) {
        List<Persona> list = null;
        String sql = "";
        try {
            sql = "SELECT p FROM Persona p where p.id_sucursal = ?1";
            Query q = em.createQuery(sql);
            q.setParameter(1, s);

            if (q.getResultList() != null) {
                list = q.getResultList();
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Error de query getPerSucursal " + e.getMessage());
        }
        return list;
    }
    
    /*RECOJER PERSONA POR ID PARA POSTERIORMENTE RECOJER LA SUCURSAL*/
    @Override
    public Persona getPersona(Usuario us) {
        List<Persona> lista = null;
        String sql = "";
        Persona per = null;
        try {
            sql = "SELECT p FROM Persona p WHERE p.id_persona = ?1";
            Query q = em.createQuery(sql);

            q.setParameter(1, us.getId_persona().getId_persona());

            lista = q.getResultList();

            if (!lista.isEmpty()) {
                per = lista.get(0);
            } else {
                System.err.println("NO SE EJECUTO QUERY PEDIDO FACADE");
            }

        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("ERROR GRAVE");
        }
        return per;
    }
}
