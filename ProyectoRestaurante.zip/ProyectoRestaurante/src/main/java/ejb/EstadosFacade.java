/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import entity.Estados;
import entity.Persona;
import entity.RegistrosInicio;
import entity.Usuario;
import entity.Venta;
import java.util.Date;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TemporalType;

@Stateless
public class EstadosFacade extends AbstractFacade<Estados> implements EstadosFacadeLocal {

    @PersistenceContext(unitName = "pvb")

    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public EstadosFacade() {
        super(Estados.class);
    }

    /*RECOJER PERSONA POR ID PARA POSTERIORMENTE RECOJER LA SUCURSAL*/
    @Override
    public Persona getPersona(Usuario us) {
        List<Persona> lista = null;
        String sql = null;
        Persona per = null;
        try {
            sql = "SELECT p FROM Persona p WHERE p.id_persona = ?1";
            Query q = em.createQuery(sql);

            q.setParameter(1, us.getId_persona().getId_persona());

            lista = q.getResultList();

            if (!lista.isEmpty()) {
                per = lista.get(0);
                System.out.println("LISTA BIEN HECHA :D" + per.getId_sucursal().getId_sucursal());
            } else {
                System.err.println("NO SE EJECUTO QUERY PEDIDO FACADE");
            }

        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("ERROR GRAVE" + e.getMessage());
        }
        return per;
    }

    //Obtener las ventas para todas las sucursales
    @Override
    public double getVnt(Date d1, Date d2) {
        double totalvnt = 0.00;
        try {
            String sql = "SELECT SUM(v.venta_total) FROM Venta v WHERE v.fecha_hora BETWEEN :d1 and :d2";
            Query q = em.createQuery(sql);
            q.setParameter("d1", d1, TemporalType.TIMESTAMP);
            q.setParameter("d2", d2, TemporalType.TIMESTAMP);
            List<Double> l = q.getResultList();
            if (q.getResultList() != null) {
                if (!l.isEmpty()) {
                    totalvnt = l.get(0);
                    System.out.println(totalvnt + "JAJA");
                }
            } else {
                System.out.println("No q result founded getVnt att:Fer");
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("ERROR DE QUERY getVnt " + e.getMessage());
        }
        return totalvnt;
    }

    @Override
    public double getValInvInit(Date d1, Date d2) {
        double valorInv = 0.00;
        RegistrosInicio reg = new RegistrosInicio();

        try {
            String sql = "SELECT r FROM RegistrosInicio r where r.fecha_registro BETWEEN :d1 and :d2 order by r.fecha_registro ASC";
            Query q = em.createQuery(sql);
            q.setParameter("d1", d1, TemporalType.TIMESTAMP);
            q.setParameter("d2", d2, TemporalType.TIMESTAMP);

            if (q.getResultList() != null) {
                List<RegistrosInicio> list = q.getResultList();
                if (!list.isEmpty()) {
                    reg = list.get(0);
                    valorInv = reg.getValor_inv();
                }
            } else {
                System.err.println("No q result founded getValInvInit att:Fer");
            }

        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Erro de query getValInv " + e.getMessage());
        }
        return valorInv;
    }

    @Override
    public double getValInvEnd(Date d1, Date d2) {
        double valorInv = 0.00;
        RegistrosInicio reg = new RegistrosInicio();

        try {
            String sql = "SELECT r FROM RegistrosInicio r where r.fecha_registro BETWEEN :d1 and :d2 order by r.fecha_registro DESC";
            Query q = em.createQuery(sql);
            q.setParameter("d1", d1, TemporalType.TIMESTAMP);
            q.setParameter("d2", d2, TemporalType.TIMESTAMP);

            if (q.getResultList() != null) {
                List<RegistrosInicio> list = q.getResultList();
                if (!list.isEmpty()) {
                    reg = list.get(0);
                    valorInv = reg.getValor_inv();
                }
            } else {
                System.err.println("No q result founded getValInvEnd att:Fer");
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Erro de query getValInv " + e.getMessage());
        }
        return valorInv;
    }

    @Override
    public double getCompras(Date d1, Date d2) {
        double valorCmp = 0.00;
        try {
            String sql = "SELECT  SUM(c.valor_en_inv) FROM DetalleProducto c where c.fecha_hora BETWEEN :d1 and :d2";
            Query q = em.createQuery(sql);
            q.setParameter("d1", d1, TemporalType.TIMESTAMP);
            q.setParameter("d2", d2, TemporalType.TIMESTAMP);

            if (q.getResultList() != null) {
                List<Double> l = q.getResultList();
                if (!l.isEmpty()) {
                    valorCmp = l.get(0);
                    System.out.println(valorCmp);
                }
            } else {
                System.out.println("No q result founded  getCompras att:Fer");
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Error de query getCompras " + e.getMessage());
        }
        return valorCmp;
    }

    @Override
    public List<Estados> getReport(Date d1, Date d2) {
        List<Estados> lista = null;
        try {
            String sql = "SELECT e FROM Estados e WHERE e.inicio BETWEEN :startDate AND :endDate order by e.inicio  ASC";
            Query q = em.createQuery(sql);
            q.setParameter("startDate", d1, TemporalType.TIMESTAMP);
            q.setParameter("endDate", d2, TemporalType.TIMESTAMP);
            lista = q.getResultList();

            if (!lista.isEmpty()) {
                System.out.println("LLENAAA");
            } else {
                System.out.println("VACIAAA");
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("ERROOR " + e.getMessage());
        }
        return lista;
    }

}
