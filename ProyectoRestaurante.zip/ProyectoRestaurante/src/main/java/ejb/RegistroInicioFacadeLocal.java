/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import entity.DetalleProducto;
import entity.DetalleVenta;
import entity.Persona;
import entity.RegistrosInicio;
import entity.Usuario;
import entity.Venta;
import java.util.Date;
import java.util.List;
import javax.ejb.Local;

@Local
public interface RegistroInicioFacadeLocal {

    void create(RegistrosInicio encuesta);

    List<RegistrosInicio> findAll();

    void edit(RegistrosInicio entity);

    void delete(RegistrosInicio entity);

    RegistrosInicio find(Object id);

    Persona getPersona(Usuario us);

    int getInvReg();
    
    List<Venta> getTodayVnt(Date d1, Date d2);
    
    List<DetalleProducto> getTodayDet(Date d1, Date d2);
    
    List<DetalleVenta> getDetail(Venta ven);
    
    double getValorInv();
}
