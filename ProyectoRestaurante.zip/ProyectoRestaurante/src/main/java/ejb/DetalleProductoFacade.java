/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import entity.DetalleProducto;
import entity.Persona;
import entity.Producto;
import entity.Sucursal;
import entity.Usuario;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

@Stateless
public class DetalleProductoFacade extends AbstractFacade<DetalleProducto> implements DetalleProductoFacadeLocal {

    @PersistenceContext(name = "pvb")
    private EntityManager em;

    public DetalleProductoFacade() {
        super(DetalleProducto.class);
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    /*OBTENER EL COSTO DEL PRODUCTO EN INGRESO*/
    @Override
    public Producto getCosto(Producto id) {
        Producto p = null;
        String sql = null;
        List<Producto> lista = null;
        try {
            sql = "SELECT p FROM Producto p WHERE p.id_producto = ?1";;

            Query q = em.createQuery(sql);
            q.setParameter(1, id.getId_producto());

            lista = q.getResultList();

            if (!lista.isEmpty()) {
                p = lista.get(0);
            } else {
                System.err.println("NO SE EJECUTO CORRECTAMENTE");
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("ERROR GRAVE DETALLE PRODUCTO FACADE");
        }
        return p;
    }

    /*RECOJER PERSONA POR ID PARA POSTERIORMENTE RECOJER LA SUCURSAL*/
    @Override
    public Persona getPersona(Usuario us) {
        List<Persona> lista = null;
        String sql = null;
        Persona per = null;
        try {
            sql = "SELECT p FROM Persona p WHERE p.id_persona = ?1";
            Query q = em.createQuery(sql);

            q.setParameter(1, us.getId_persona().getId_persona());

            lista = q.getResultList();

            if (!lista.isEmpty()) {
                per = lista.get(0);
            } else {
                System.err.println("NO SE EJECUTO QUERY PEDIDO FACADE");
            }

        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("ERROR GRAVE");
        }
        return per;
    }

    @Override
    public List<DetalleProducto> getDetProSucursal(Sucursal suc) {
        List<DetalleProducto> list = null;
        String sql = "";
        try {
            sql = "SELECT d FROM DetalleProducto d WHERE d.id_sucursal = ?1";
            Query q = em.createQuery(sql);
            q.setParameter(1, suc);

            if (q.getResultList() != null) {
                list = q.getResultList();
            } else {
                System.err.println("Lista vacia getDetProSucursal ");
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Error de query getDetProSucursal " + e.getMessage());
        }
        return list;
    }

}
