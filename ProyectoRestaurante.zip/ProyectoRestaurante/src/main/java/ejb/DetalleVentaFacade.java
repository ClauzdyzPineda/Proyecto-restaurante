/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import entity.Bebida;
import entity.Complemento;
import entity.DetallePlatillo;
import entity.DetalleVenta;
import entity.Platillo;
import entity.Producto;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

@Stateless(name = "sdetalle")
public class DetalleVentaFacade extends AbstractFacade<DetalleVenta> implements DetalleVentaFacadeLocal {

    @PersistenceContext(unitName = "pvb")

    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public DetalleVentaFacade() {
        super(DetalleVenta.class);
    }

    //Recojer todos los datos de platillo.
    @Override
    public Platillo getPlatillo(Platillo p) {
        Platillo pl = new Platillo();
        String sql = "";
        try {
            sql = "SELECT p from Platillo p WHERE p.id_platillo = ?1";

            Query q = em.createQuery(sql);
            q.setParameter(1, p.getId_platillo());

            List<Platillo> lista = q.getResultList();

            if (!lista.isEmpty()) {
                pl = lista.get(0);
            } else {
                System.err.println("La lista se encuentra vacia");
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("ERROR AL EJECUTAR QUERY getPLatillo " + e.getMessage());
        }
        return pl;
    }

    //Recojer todos los datos de bebida.
    @Override
    public Bebida getBebida(Bebida b) {
        Bebida be = new Bebida();
        String sql = "";
        try {
            sql = "SELECT b from Bebida b WHERE b.id_bebida = ?1";

            Query q = em.createQuery(sql);
            q.setParameter(1, b.getId_bebida());

            List<Bebida> lista = q.getResultList();

            if (!lista.isEmpty()) {
                be = lista.get(0);
            } else {
                System.err.println("La lista se encuentra vacia");
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("ERROR AL EJECUTAR QUERY getBebida " + e.getMessage());
        }
        return be;
    }

    //Recojer todos los datos de bebida.
    @Override
    public Complemento getComplemento(Complemento c) {
        Complemento co = new Complemento();
        String sql = "";
        try {
            sql = "SELECT c from Complemento c WHERE c.id_complemento = ?1";

            Query q = em.createQuery(sql);
            q.setParameter(1, c.getId_complemento());

            List<Complemento> lista = q.getResultList();

            if (!lista.isEmpty()) {
                co = lista.get(0);
            } else {
                System.err.println("La lista se encuentra vacia");
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("ERROR AL EJECUTAR QUERY getBebida " + e.getMessage());
        }
        return co;
    }

    //Lista para recojer los ingredientes correspondientes al platillo
    @Override
    public List<DetallePlatillo> getDetailList(Platillo pla) {
        List<DetallePlatillo> lista = null;
        String sql = "";
        try {
            sql = "SELECT d FROM DetallePlatillo d WHERE d.id_platillo = ?1";
            Query q = em.createQuery(sql);
            q.setParameter(1, pla);

            lista = q.getResultList();
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("ERROR AL EJECUTAR QUERY getDetailList " + e.getMessage());
        }
        return lista;
    }

    @Override
    public Producto getProducto(DetallePlatillo d) {
        Producto p = new Producto();
        String sql = "";
        try {
            
            sql = "SELECT p FROM Producto p WHERE p.id_producto = ?1";
            Query q = em.createQuery(sql);
            q.setParameter(1, d.getId_producto().getId_producto());

            List<Producto> l = q.getResultList();

            if (!l.isEmpty()) {
                p = l.get(0);
            } else {
                System.err.println("LISTA VACIA...");
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("ERROR AL EJECUTAR QUERY getDetailList " + e.getMessage());
        }

        return p;
    }
}
