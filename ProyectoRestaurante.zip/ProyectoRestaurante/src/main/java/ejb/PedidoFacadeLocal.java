/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import entity.Pedido;
import entity.Persona;
import entity.Sucursal;
import entity.Usuario;
import java.util.List;
import javax.ejb.Local;

@Local
public interface PedidoFacadeLocal {
     void create(Pedido pedido);
    
    List<Pedido> findAll();
    
    void edit(Pedido pedido);
    
    void delete(Pedido pedido);
    
    Pedido find(Object id);
    
    /*RECOJER PERSONA PARA ID DE SUCURSAL*/
    Persona getPersona(Usuario us);
    
    //Listado de pedidos por sucursal
    List<Pedido> getPedSucursal(Sucursal s);
    
    double getValor_Pro (int pro);
   
}
