/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import entity.Producto;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

@Stateless(name = "prodFacade")
public class ProductoFacade extends AbstractFacade<Producto> implements ProductoFacadeLocal {

    @PersistenceContext(unitName = "pvb")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public ProductoFacade() {
        super(Producto.class);
    }

    @Override
    public List<Producto> getBebidas() {
        List<Producto> lista = null;
        String sql = null;
        try {
            sql = "SELECT p FROM Producto p WHERE p.tipo = B";
            Query q = em.createQuery(sql);
            lista = q.getResultList();
            if (!lista.isEmpty()) {
                System.out.println("Lista llena");
            } else {
                System.err.println("Lista vacia");
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("No se puede ejecutar el query");
        }
        return lista;
    }

    @Override
    public List<Producto> getComplementos() {
        List<Producto> lista = null;
        String sql = null;
        try {
            sql = "SELECT p FROM Producto p WHERE p.tipo = C";
            Query q = em.createQuery(sql);
            lista = q.getResultList();
            if (!lista.isEmpty()) {
                System.out.println("Lista llena");
            } else {
                System.err.println("Lista vacia");
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("No se puede ejecutar el query");
        }
        return lista;
    }

    /*Funcional, nos sirve a la hora de añadir ingredientes al platillo en la sección de viewPlatillo*/
    @Override
    public List<Producto> listaIng() {
        List<Producto> lista = null;
        String sql;
        try {
            sql = "SELECT  p FROM Producto p WHERE p.tipo = 'C' or p.tipo = 'A'";
            Query q = em.createQuery(sql);

            lista = q.getResultList();
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("No se puede ejecutar el query");
        }
        return lista;
    }
}
