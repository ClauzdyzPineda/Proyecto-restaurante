/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import entity.DetalleVenta;
import entity.Persona;
import entity.Sucursal;
import entity.Usuario;
import entity.Venta;
import java.util.Date;
import java.util.List;
import javax.ejb.Local;

@Local
public interface VentaFacadeLocal {

    void create(Venta v);

    void edit(Venta v);

    void delete(Venta v);

    List<Venta> findAll();

    Venta find(Object id);

    //Obtener la persona a la que corresponde el usuario en curso
    Persona getPersona(Usuario us);

    //Obtener todo lo vendido para un registro
    List<DetalleVenta> getDetail(Venta ven);
    
    //Generar reporte de ventas basado en intervalo de fechas
    List<Venta> getReport(Date d1, Date d2);
    
    //Ventas de una sucursal en concreto
    List<Venta> getVntSucursal(Sucursal suc);
    
    //Obtener reporte de una sucursal en especifico
    List<Venta> getReportUser(Date d1, Date d2, Sucursal s);
    
    //Obtener ventas del usuario en sesión
    List<Venta> getVntUserInLog(Usuario us);
    
    //Obtener ventas dewl día
    List<Venta> getMyVntDay(Usuario us);

}
