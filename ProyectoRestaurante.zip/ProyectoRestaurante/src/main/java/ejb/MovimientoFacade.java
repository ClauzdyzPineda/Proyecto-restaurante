/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import entity.Movimiento;
import entity.Persona;
import entity.Sucursal;
import entity.Usuario;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author marlon.mazariegousam
 */
@Stateless
public class MovimientoFacade extends AbstractFacade<Movimiento> implements MovimientoFacadeLocal {

    @PersistenceContext(name = "pvb")
    private EntityManager em;

    public MovimientoFacade() {
        super(Movimiento.class);
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    @Override
    public List<Movimiento> getListSucursal(Sucursal s) {
        List<Movimiento> list = null;
        String sql = "";
        try {
            sql = "SELECT m FROM Movimiento m WHERE m.id_sucursal = ?1";
            Query q = em.createQuery(sql);
            q.setParameter(1, s);

            if (q.getResultList() != null) {
                list = q.getResultList();
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Error de query getListSucursal " + e.getMessage());
        }
        return list;
    }

    /*RECOJER PERSONA POR ID PARA POSTERIORMENTE RECOJER LA SUCURSAL*/
    @Override
    public Persona getPersona(Usuario us) {
        List<Persona> lista = null;
        String sql = null;
        Persona per = null;
        try {
            sql = "SELECT p FROM Persona p WHERE p.id_persona = ?1";
            Query q = em.createQuery(sql);

            q.setParameter(1, us.getId_persona().getId_persona());

            lista = q.getResultList();

            if (!lista.isEmpty()) {
                per = lista.get(0);
                System.out.println("LISTA BIEN HECHA :D" + per.getId_sucursal().getId_sucursal());
            } else {
                System.err.println("NO SE EJECUTO QUERY PEDIDO FACADE");
            }

        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("ERROR GRAVE");
        }
        return per;
    }

}
