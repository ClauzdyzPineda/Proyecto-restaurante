/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import entity.DetalleVenta;
import entity.Persona;
import entity.Sucursal;
import entity.Usuario;
import entity.Venta;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TemporalType;

@Stateless(name = "sventa")
public class VentaFacade extends AbstractFacade<Venta> implements VentaFacadeLocal {

    @PersistenceContext(name = "pvb")
    private EntityManager em;

    public VentaFacade() {
        super(Venta.class);
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    //Obtener ventas del usuario en sesión
    @Override
    public List<Venta> getVntUserInLog(Usuario us) {
        List<Venta> list = null;
        String sql = "";
        try {
            sql = "SELECT v FROM Venta v WHERE v.id_usuario = ?1 order by v.fecha_hora ASC";
            Query q = em.createQuery(sql);
            q.setParameter(1, us);

            if (q.getResultList() != null) {
                list = q.getResultList();
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("ERROOR getListUserInLog" + e.getMessage());
        }
        return list;
    }

    //Obtener ventas de una sucursal en concreto
    @Override
    public List<Venta> getVntSucursal(Sucursal suc) {
        List<Venta> list = null;
        String sql = "";
        try {
            sql = "SELECT v FROM Venta v WHERE v.id_sucursal = ?1";
            Query q = em.createQuery(sql);
            q.setParameter(1, suc);

            if (q.getResultList() != null) {
                list = q.getResultList();
            } else {
                Venta v = new Venta();
                v.setId_venta(1);
                v.setNombre_cliente("No hay registro");
                list.add(v);
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Error de query getVntSucursal " + e.getMessage());
        }
        return list;
    }

    /*RECOJER PERSONA POR ID PARA POSTERIORMENTE RECOJER LA SUCURSAL*/
    @Override
    public Persona getPersona(Usuario us) {
        List<Persona> lista = null;
        String sql = "";
        Persona per = null;
        try {
            sql = "SELECT p FROM Persona p WHERE p.id_persona = ?1";
            Query q = em.createQuery(sql);

            q.setParameter(1, us.getId_persona().getId_persona());

            lista = q.getResultList();

            if (!lista.isEmpty()) {
                per = lista.get(0);
            } else {
                System.err.println("NO SE EJECUTO QUERY PEDIDO FACADE");
            }

        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("ERROR GRAVE");
        }
        return per;
    }

    //RECOJEMOS TODO LO QUE SE VENDIO DE UNA TABLA EXTERNA A LA DE VENTAS
    @Override
    public List<DetalleVenta> getDetail(Venta ven) {
        List<DetalleVenta> lista = null;
        String sql = "";

        try {
            sql = "SELECT d from DetalleVenta d WHERE d.id_venta = ?1";
            Query q = em.createQuery(sql);
            q.setParameter(1, ven);

            lista = q.getResultList();

            if (!lista.isEmpty()) {
                System.out.println("SI");
            } else {
                System.out.println("NO");
            }

        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("ERROR DE QUERY " + e.getMessage());
        }
        return lista;
    }

    //Query para recoger registros basados en fecha
    @Override
    public List<Venta> getReport(Date d1, Date d2) {
        List<Venta> lista = null;
        try {
            String sql = "SELECT v FROM Venta v WHERE v.fecha_hora BETWEEN :startDate AND :endDate order by v.fecha_hora ASC";
            Query q = em.createQuery(sql);
            q.setParameter("startDate", d1, TemporalType.TIMESTAMP);
            q.setParameter("endDate", d2, TemporalType.TIMESTAMP);
            lista = q.getResultList();

            if (!lista.isEmpty()) {
                System.out.println("LLENAAA");
            } else {
                System.out.println("VACIAAA");
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("ERROOR " + e.getMessage());
        }
        return lista;
    }

    //Obtener registros de una fecha y sucursal en concreto
    @Override
    public List<Venta> getReportUser(Date d1, Date d2, Sucursal s) {
        List<Venta> lista = null;
        try {
            String sql = "SELECT v FROM Venta v WHERE v.fecha_hora BETWEEN :startDate AND :endDate AND v.id_sucursal = :suc"
                    + " order by v.fecha_hora ASC";
            Query q = em.createQuery(sql);
            q.setParameter("startDate", d1, TemporalType.TIMESTAMP);
            q.setParameter("endDate", d2, TemporalType.TIMESTAMP);
            q.setParameter("suc", s);
            lista = q.getResultList();

            if (q.getResultList() != null) {
                lista = q.getResultList();
                if (!lista.isEmpty()) {
                    System.out.println("LLENAAA");
                } else {
                    System.out.println("VACIAAA");
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("ERROOR " + e.getMessage());
        }
        return lista;
    }

    //Obtener los registros de un día para un usuario
    @Override
    public List<Venta> getMyVntDay(Usuario us) {
        List<Venta> list = null;
        String sql = "";
        Date d1 = new Date();
        Date d2 = new Date();
        SimpleDateFormat con1 = new SimpleDateFormat("dd/MM/yyyy");
        SimpleDateFormat con2 = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        String converted1 = con1.format(d1) + " 00:00:00";
        String converted2 = con2.format(d2) + " 23:59:59";
        try {
            d1 = con2.parse(converted1);
            d2 = con2.parse(converted2);
            sql = "SELECT v FROM Venta v WHERE v.fecha_hora BETWEEN :startDate AND :endDate AND v.id_usuario = :usu"
                    + " order by v.fecha_hora ASC";
            Query q = em.createQuery(sql);
            q.setParameter("startDate", d1, TemporalType.TIMESTAMP);
            q.setParameter("endDate", d2, TemporalType.TIMESTAMP);
            q.setParameter("usu", us);
            
            if (q.getResultList() != null) {
                list = q.getResultList();
            }

        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("ERROOR getMyVntDay" + e.getMessage());
        }
        return list;
    }

}
